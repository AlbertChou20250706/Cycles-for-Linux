#!/bin/bash

################################################################################
# Project  : Albert SIT Configurator
# Version  : 3.0 (v5.0 Architecture - IPMI Auto-Configuration)
# Author   : Albert Zhou (志偉 周) — Refactored by Senior Engineer Review
# Date     : 2026-04-29
# License  : MIT
#
# WHAT'S NEW in v3.0:
#   1. ✅ 互動式 IPMI / BMC 配置:直接輸入 BMC IP/User/Pass,自動產出
#         config/ipmi.conf (chmod 600,密碼以 read -s 隱藏)
#   2. ✅ 存檔前自動測試 IPMI 連線 (chassis status),失敗會讓使用者重輸
#   3. ✅ 自動偵測 BMC chassis policy,若非 always-on 自動詢問套用並驗證
#   4. ✅ 智能清理:重新執行 ver.sh 時保留 ipmi.conf,只清測試項目相關檔
#   5. ✅ 依賴檢查:ipmitool 未安裝會引導 dnf install
#   6. ✅ 與 v5.0 engine + regression 的佇列架構完全相容
#
# Usage:
#   sudo bash ver.sh
#
# Requirements:
#   - RHEL 9.4 or compatible
#   - Root privileges
#   - 150+ MB free disk space
#   - ipmitool (AC/DC 測試需要)
#
################################################################################

set -euo pipefail

# ==============================================================================
# Global Configuration
# ==============================================================================

readonly SCRIPT_VERSION="3.0"
readonly SCRIPT_NAME="Albert SIT Configurator"
readonly MIN_DISK_SPACE=$((150 * 1024))  # KB
readonly CONFIG_DIR="./config"
readonly IPMI_CONF="${CONFIG_DIR}/ipmi.conf"

# Colors
readonly C_BOLD="\e[1m"
readonly C_INFO="\e[1;36m"
readonly C_PASS="\e[1;32m"
readonly C_WARN="\e[1;33m"
readonly C_ERROR="\e[1;31m"
readonly C_DEBUG="\e[0;37m"
readonly C_RESET="\e[0m"

# ==============================================================================
# Logging
# ==============================================================================

log_info()  { echo -e "${C_INFO}[INFO]${C_RESET} $1"; }
log_pass()  { echo -e "${C_PASS}[PASS]${C_RESET} $1"; }
log_warn()  { echo -e "${C_WARN}[WARN]${C_RESET} $1"; }
log_error() { echo -e "${C_ERROR}[ERROR]${C_RESET} $1"; }
log_debug() {
    if [[ "${DEBUG:-0}" == "1" ]]; then
        echo -e "${C_DEBUG}[DEBUG]${C_RESET} $1"
    fi
}

# ==============================================================================
# Pre-flight Checks
# ==============================================================================

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "此腳本需要 root 權限執行"
        log_info "請使用: sudo bash ver.sh"
        exit 1
    fi
    log_pass "✓ Root 權限驗證通過"
}

check_rhel_version() {
    if [[ ! -f /etc/os-release ]]; then
        log_error "無法讀取 /etc/os-release"
        exit 1
    fi

    if grep -q "Red Hat Enterprise Linux" /etc/os-release; then
        local version
        version=$(grep "^VERSION_ID=" /etc/os-release | cut -d'"' -f2)
        log_pass "✓ 檢測到 RHEL $version"
    else
        log_warn "⚠️  非 RHEL 系統,某些功能可能不可用"
    fi
}

check_disk_space() {
    local available
    available=$(df /root/Documents 2>/dev/null | awk 'NR==2 {print $4}' || echo 0)

    if [[ ${available:-0} -lt $MIN_DISK_SPACE ]]; then
        log_warn "⚠️  磁碟空間不足 (可用: ${available}KB,需要: ${MIN_DISK_SPACE}KB)"
        log_warn "測試可能無法完成,請清理磁碟空間"
    else
        log_pass "✓ 磁碟空間充足"
    fi
}

# ==============================================================================
# Validation Helpers
# ==============================================================================

validate_cycles() {
    local input=$1
    local name=$2

    if [[ ! "$input" =~ ^[0-9]+$ ]]; then
        log_warn "❌ 無效的循環次數: '$input',改用預設值 10" >&2
        echo 10
        return 1
    fi

    if [[ "$input" -lt 1 ]]; then
        log_warn "❌ 循環次數必須 >= 1,改用預設值 10" >&2
        echo 10
        return 1
    fi

    if [[ "$input" -gt 1000 ]]; then
        log_warn "❌ 循環次數過多 (>1000),改用預設值 10" >&2
        echo 10
        return 1
    fi

    echo "$input"
    return 0
}

validate_ip_or_host() {
    local addr=$1
    # IPv4
    if [[ "$addr" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        local IFS='.'
        local -a octets=($addr)
        for o in "${octets[@]}"; do
            (( o >= 0 && o <= 255 )) || return 1
        done
        return 0
    fi
    # Hostname (basic)
    if [[ "$addr" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]{0,253}[a-zA-Z0-9]$ ]] \
       || [[ "$addr" =~ ^[a-zA-Z0-9]$ ]]; then
        return 0
    fi
    return 1
}

# ==============================================================================
# Cleanup (smart: preserves ipmi.conf)
# ==============================================================================

cleanup_old_configs() {
    log_warn "清理舊的測試項目配置 (保留 ipmi.conf)..."

    # 只刪測試項目相關檔,保留 ipmi.conf
    local files=(
        "$CONFIG_DIR/regression_test"
        "$CONFIG_DIR/testitem"
        "$CONFIG_DIR/error_policy"
        "$CONFIG_DIR/test_queue.run"
        "$CONFIG_DIR/reboot_test"  "$CONFIG_DIR/reboottime"
        "$CONFIG_DIR/ac_test"      "$CONFIG_DIR/ac_time"
        "$CONFIG_DIR/dc_test"      "$CONFIG_DIR/dc_time"
        "$CONFIG_DIR/shutdown_test" "$CONFIG_DIR/shutdown_time"
    )
    for f in "${files[@]}"; do
        rm -f "$f" 2>/dev/null || true
    done

    # 清理跨 boot 的狀態 (避免幽靈圈數)
    rm -f /root/Documents/Albert_Cycle_State.ini 2>/dev/null || true
    rm -f /root/Documents/.current_session       2>/dev/null || true
    rm -f ~/.config/autostart/auto_test.desktop  2>/dev/null || true
    rm -f /etc/auto_test.desktop                 2>/dev/null || true

    if [[ -f "$IPMI_CONF" ]]; then
        log_debug "保留既有 IPMI 配置: $IPMI_CONF"
    fi

    log_pass "✓ 舊配置已清理"
}

initialize_config_dir() {
    log_info "初始化配置目錄..."
    mkdir -p "$CONFIG_DIR"
    chmod 755 "$CONFIG_DIR"
    touch "$CONFIG_DIR/regression_test"
    touch "$CONFIG_DIR/testitem"
    log_pass "✓ 配置目錄已初始化: $CONFIG_DIR"
}

# ==============================================================================
# Test Type Configuration
# ==============================================================================

configure_reboot_test() {
    echo ""
    read -r -p "👉 執行 Reboot 測試? (y/N): " do_it
    if [[ ! "$do_it" =~ ^[Yy]$ ]]; then
        return 0
    fi

    read -r -p "   📊 Reboot 循環次數 (預設 10): " n
    n=${n:-10}
    n=$(validate_cycles "$n" "Reboot")

    echo "$n" > "$CONFIG_DIR/reboottime"
    touch "$CONFIG_DIR/reboot_test"
    echo "Reboot Test - $n cycles" >> "$CONFIG_DIR/testitem"
    log_pass "✓ Reboot 測試已配置: $n 循環"
}

configure_ac_test() {
    echo ""
    read -r -p "👉 執行 AC Cycle 測試? (y/N): " do_it
    if [[ ! "$do_it" =~ ^[Yy]$ ]]; then
        return 0
    fi

    read -r -p "   📊 AC Cycle 循環次數 (預設 10): " n
    n=${n:-10}
    n=$(validate_cycles "$n" "AC")

    echo "$n" > "$CONFIG_DIR/ac_time"
    touch "$CONFIG_DIR/ac_test"
    echo "AC Cycle Test - $n cycles" >> "$CONFIG_DIR/testitem"
    log_pass "✓ AC Cycle 測試已配置: $n 循環"
}

configure_dc_test() {
    echo ""
    read -r -p "👉 執行 DC Cycle 測試? (y/N): " do_it
    if [[ ! "$do_it" =~ ^[Yy]$ ]]; then
        return 0
    fi

    read -r -p "   📊 DC Cycle 循環次數 (預設 10): " n
    n=${n:-10}
    n=$(validate_cycles "$n" "DC")

    echo "$n" > "$CONFIG_DIR/dc_time"
    touch "$CONFIG_DIR/dc_test"
    echo "DC Cycle Test - $n cycles" >> "$CONFIG_DIR/testitem"
    log_pass "✓ DC Cycle 測試已配置: $n 循環"
}

configure_shutdown_test() {
    echo ""
    read -r -p "👉 執行 Shutdown (S5) 測試? (y/N): " do_it
    if [[ ! "$do_it" =~ ^[Yy]$ ]]; then
        return 0
    fi

    read -r -p "   📊 Shutdown 循環次數 (預設 10): " n
    n=${n:-10}
    n=$(validate_cycles "$n" "Shutdown")

    echo "$n" > "$CONFIG_DIR/shutdown_time"
    touch "$CONFIG_DIR/shutdown_test"
    echo "Shutdown Test - $n cycles" >> "$CONFIG_DIR/testitem"
    log_pass "✓ Shutdown 測試已配置: $n 循環"
}

# ==============================================================================
# IPMI Subsystem (NEW in v3.0)
# ==============================================================================

ipmi_needed() {
    [[ -f "$CONFIG_DIR/ac_test" ]] || [[ -f "$CONFIG_DIR/dc_test" ]]
}

check_ipmitool_installed() {
    if command -v ipmitool &>/dev/null; then
        log_pass "✓ ipmitool 已安裝 ($(ipmitool -V 2>&1 | head -n1))"
        return 0
    fi

    log_warn "❌ ipmitool 未安裝"

    if command -v dnf &>/dev/null; then
        echo ""
        read -r -p "現在透過 dnf 安裝 ipmitool? (Y/n): " ans
        if [[ ! "$ans" =~ ^[Nn]$ ]]; then
            log_info "安裝中..."
            if dnf install -y ipmitool; then
                log_pass "✓ ipmitool 安裝成功"
                return 0
            fi
            log_error "ipmitool 安裝失敗"
        fi
    fi

    log_error "請手動安裝 ipmitool 後再執行此腳本"
    return 1
}

ipmi_show_existing() {
    # 顯示現有 ipmi.conf,密碼遮罩
    if [[ ! -f "$IPMI_CONF" ]]; then
        return 1
    fi

    local host user pass intf masked
    # 安全 source:在 subshell 中
    host=$(grep "^IPMI_HOST="      "$IPMI_CONF" 2>/dev/null | cut -d= -f2-)
    user=$(grep "^IPMI_USER="      "$IPMI_CONF" 2>/dev/null | cut -d= -f2-)
    pass=$(grep "^IPMI_PASS="      "$IPMI_CONF" 2>/dev/null | cut -d= -f2-)
    intf=$(grep "^IPMI_INTERFACE=" "$IPMI_CONF" 2>/dev/null | cut -d= -f2-)

    masked=""
    if [[ -n "$pass" ]]; then
        local len=${#pass}
        if (( len <= 2 )); then
            masked="**"
        else
            masked="${pass:0:1}$(printf '%*s' "$((len - 2))" '' | tr ' ' '*')${pass: -1}"
        fi
    fi

    echo ""
    echo -e "${C_INFO}── 現有 IPMI 配置 ──${C_RESET}"
    echo "  IPMI_HOST      = ${host:-<空>}"
    echo "  IPMI_USER      = ${user:-<空>}"
    echo "  IPMI_PASS      = ${masked:-<空>}"
    echo "  IPMI_INTERFACE = ${intf:-lanplus}"
    echo ""
    return 0
}

ipmi_prompt_credentials() {
    # 互動式輸入並寫入 ipmi.conf
    local host user pass intf

    echo ""
    log_info "請輸入 BMC 連線資訊 (Out-of-band lanplus):"

    # IP / hostname
    while true; do
        read -r -p "   BMC IP 或主機名: " host
        if [[ -z "$host" ]]; then
            log_warn "不可為空,請重新輸入"
            continue
        fi
        if validate_ip_or_host "$host"; then
            break
        fi
        log_warn "無效的 IP 或主機名: $host"
    done

    # User
    read -r -p "   BMC 帳號 (預設 root): " user
    user=${user:-root}

    # Password (hidden)
    while true; do
        read -r -s -p "   BMC 密碼: " pass
        echo ""
        if [[ -z "$pass" ]]; then
            log_warn "密碼不可為空,請重新輸入"
            continue
        fi
        # 二次確認 (避免打錯)
        local pass2
        read -r -s -p "   再輸入一次以確認: " pass2
        echo ""
        if [[ "$pass" == "$pass2" ]]; then
            break
        fi
        log_warn "兩次輸入不一致,請重試"
    done

    # Interface
    while true; do
        read -r -p "   IPMI Interface [lanplus/lan/open] (預設 lanplus): " intf
        intf=${intf:-lanplus}
        case "$intf" in
            lanplus|lan|open) break ;;
            *) log_warn "無效的 interface,請輸入 lanplus / lan / open" ;;
        esac
    done

    # 寫入 (不要用 EOF heredoc + 變數展開時被 $ 字元刺傷,改用 printf)
    {
        echo "# Auto-generated by ver.sh v${SCRIPT_VERSION} at $(date '+%Y-%m-%d %H:%M:%S')"
        echo "# DO NOT commit this file to git (contains credentials)"
        echo "IPMI_HOST=${host}"
        echo "IPMI_USER=${user}"
        echo "IPMI_PASS=${pass}"
        echo "IPMI_INTERFACE=${intf}"
    } > "$IPMI_CONF"

    chmod 600 "$IPMI_CONF"
    log_pass "✓ IPMI 配置已寫入 $IPMI_CONF (chmod 600)"
}

ipmi_test_connection() {
    # 從 ipmi.conf 讀取參數,執行 chassis status 測試
    if [[ ! -f "$IPMI_CONF" ]]; then
        log_error "IPMI 配置檔不存在: $IPMI_CONF"
        return 1
    fi

    local host user pass intf
    host=$(grep "^IPMI_HOST="      "$IPMI_CONF" | cut -d= -f2-)
    user=$(grep "^IPMI_USER="      "$IPMI_CONF" | cut -d= -f2-)
    pass=$(grep "^IPMI_PASS="      "$IPMI_CONF" | cut -d= -f2-)
    intf=$(grep "^IPMI_INTERFACE=" "$IPMI_CONF" | cut -d= -f2-)
    intf=${intf:-lanplus}

    log_info "測試 IPMI 連線: ${user}@${host} (intf=${intf})..."

    local out rc
    set +e
    out=$(ipmitool -I "$intf" -H "$host" -U "$user" -P "$pass" chassis status 2>&1)
    rc=$?
    set -e

    if [[ $rc -eq 0 ]]; then
        log_pass "✓ IPMI 連線成功"
        echo "$out" | grep -E "System Power|Power Restore Policy" | sed 's/^/    /'
        return 0
    fi

    log_error "❌ IPMI 連線失敗 (rc=$rc):"
    echo "$out" | sed 's/^/    /'
    return 1
}

ipmi_get_current_policy() {
    # 從 chassis status 取得當前 Power Restore Policy
    if [[ ! -f "$IPMI_CONF" ]]; then
        echo "unknown"
        return
    fi

    local host user pass intf
    host=$(grep "^IPMI_HOST="      "$IPMI_CONF" | cut -d= -f2-)
    user=$(grep "^IPMI_USER="      "$IPMI_CONF" | cut -d= -f2-)
    pass=$(grep "^IPMI_PASS="      "$IPMI_CONF" | cut -d= -f2-)
    intf=$(grep "^IPMI_INTERFACE=" "$IPMI_CONF" | cut -d= -f2-)
    intf=${intf:-lanplus}

    ipmitool -I "$intf" -H "$host" -U "$user" -P "$pass" chassis status 2>/dev/null \
        | grep -i "Power Restore Policy" \
        | awk -F: '{print $2}' \
        | tr -d '[:space:]' \
        || echo "unknown"
}

ipmi_apply_always_on_policy() {
    # 套用 chassis policy always-on
    local host user pass intf
    host=$(grep "^IPMI_HOST="      "$IPMI_CONF" | cut -d= -f2-)
    user=$(grep "^IPMI_USER="      "$IPMI_CONF" | cut -d= -f2-)
    pass=$(grep "^IPMI_PASS="      "$IPMI_CONF" | cut -d= -f2-)
    intf=$(grep "^IPMI_INTERFACE=" "$IPMI_CONF" | cut -d= -f2-)
    intf=${intf:-lanplus}

    log_info "套用: ipmitool -I ${intf} -H ${host} -U ${user} chassis policy always-on"
    if ipmitool -I "$intf" -H "$host" -U "$user" -P "$pass" chassis policy always-on; then
        log_pass "✓ Policy 套用命令已送出,驗證中..."
        sleep 2
        local now
        now=$(ipmi_get_current_policy)
        log_info "目前 Power Restore Policy: $now"
        if [[ "$now" == "always-on" ]]; then
            log_pass "✓ Policy 確認為 always-on"
            return 0
        fi
        log_warn "⚠️  Policy 套用後仍非 always-on,請手動檢查"
        return 1
    fi
    log_error "❌ Policy 套用失敗"
    return 1
}

configure_ipmi() {
    if ! ipmi_needed; then
        log_debug "未啟用 AC/DC,略過 IPMI 配置"
        return 0
    fi

    echo ""
    echo -e "${C_INFO}══════════════════ IPMI / BMC 配置 ══════════════════${C_RESET}"
    log_info "AC/DC 測試需要 BMC 透過 IPMI 控制電源 (lanplus out-of-band)"

    # ── Step 1: 確認 ipmitool 已安裝 ──
    if ! check_ipmitool_installed; then
        log_warn "⚠️  ipmitool 不可用,AC/DC 測試將無法執行"
        log_warn "    跳過 IPMI 配置,請事後手動安裝 ipmitool 並補上 ipmi.conf"
        return 1
    fi

    # ── Step 2: 處理現有配置 ──
    local need_input=1
    if [[ -f "$IPMI_CONF" ]]; then
        ipmi_show_existing
        read -r -p "重用現有 IPMI 配置? (Y/n): " ans
        if [[ ! "$ans" =~ ^[Nn]$ ]]; then
            need_input=0
            log_pass "✓ 沿用現有配置"
        fi
    fi

    if [[ $need_input -eq 1 ]]; then
        ipmi_prompt_credentials
    fi

    # ── Step 3: 測試連線 (失敗可重試) ──
    while true; do
        if ipmi_test_connection; then
            break
        fi
        echo ""
        log_warn "連線測試失敗,可能原因:"
        log_warn "  • BMC IP 不通 (檢查網路 / 防火牆 / BMC 是否啟用 lanplus)"
        log_warn "  • 帳號或密碼錯誤"
        log_warn "  • Interface 不對 (lanplus / lan / open)"
        echo ""
        read -r -p "重新輸入憑證? (Y/n,n=略過繼續): " ans
        if [[ "$ans" =~ ^[Nn]$ ]]; then
            log_warn "⚠️  已略過 IPMI 連線測試,測試時可能會失敗"
            return 1
        fi
        ipmi_prompt_credentials
    done

    # ── Step 4: 檢查並套用 always-on policy ──
    echo ""
    log_info "檢查 BMC chassis power restore policy..."
    local current
    current=$(ipmi_get_current_policy)
    log_info "目前 Policy: ${current:-unknown}"

    if [[ "$current" == "always-on" ]]; then
        log_pass "✓ Policy 已是 always-on,無需變更"
        return 0
    fi

    echo ""
    log_warn "⚠️  AC/DC 測試需要 chassis policy = always-on"
    log_warn "    否則機器斷電後不會自動回來,測試會卡死"
    echo ""
    read -r -p "現在自動套用 always-on policy? (Y/n): " ans
    if [[ "$ans" =~ ^[Nn]$ ]]; then
        log_warn "⚠️  已略過,請事後手動執行:"
        log_warn "    sudo ipmitool -I lanplus -H <BMC_IP> -U <USER> -P <PASS> chassis policy always-on"
        return 0
    fi

    ipmi_apply_always_on_policy || return 1
    return 0
}

# ==============================================================================
# Error Policy
# ==============================================================================

configure_error_policy() {
    echo ""
    echo -e "${C_INFO}══════════════════ 異常處理策略 ══════════════════${C_RESET}"
    echo -e "${C_WARN}遇到硬體異常時該如何處理?${C_RESET}"
    echo -e "  ${C_PASS}1)${C_RESET} 立即停止測試 (STOP - Freeze for Debug)"
    echo -e "  ${C_PASS}2)${C_RESET} 記錄異常並繼續測試 (CONTINUE - Summarize at end)"
    echo ""
    read -r -p "👉 請選擇 (1/2) [預設 2]: " err_choice

    case "$err_choice" in
        1)
            echo "STOP" > "$CONFIG_DIR/error_policy"
            log_pass "✓ 異常處理策略: 立即停止 (STOP)"
            ;;
        *)
            echo "CONTINUE" > "$CONFIG_DIR/error_policy"
            log_pass "✓ 異常處理策略: 記錄並繼續 (CONTINUE)"
            ;;
    esac
}

# ==============================================================================
# Summary
# ==============================================================================

display_summary() {
    echo ""
    log_pass "✅ 配置完成!"
    echo ""

    echo -e "${C_WARN}已配置的測試項目:${C_RESET}"
    if [[ -s "$CONFIG_DIR/testitem" ]]; then
        sed 's/^/  ✓ /' "$CONFIG_DIR/testitem"
    else
        echo "  ℹ️  未選擇任何測試項目"
    fi

    echo ""
    echo -e "${C_PASS}異常處理策略:${C_RESET}"
    if [[ -f "$CONFIG_DIR/error_policy" ]]; then
        local policy
        policy=$(cat "$CONFIG_DIR/error_policy")
        if [[ "$policy" == "STOP" ]]; then
            echo "  🛑 立即停止 (STOP)"
        else
            echo "  ⏭️  記錄並繼續 (CONTINUE)"
        fi
    fi

    if ipmi_needed; then
        echo ""
        echo -e "${C_PASS}BMC / IPMI:${C_RESET}"
        if [[ -f "$IPMI_CONF" ]]; then
            local host user intf
            host=$(grep "^IPMI_HOST="      "$IPMI_CONF" | cut -d= -f2-)
            user=$(grep "^IPMI_USER="      "$IPMI_CONF" | cut -d= -f2-)
            intf=$(grep "^IPMI_INTERFACE=" "$IPMI_CONF" | cut -d= -f2-)
            echo "  🔌 BMC: ${user}@${host} (intf=${intf:-lanplus})"
            local pol
            pol=$(ipmi_get_current_policy 2>/dev/null || echo "unknown")
            echo "  🔁 Power Restore Policy: ${pol}"
        else
            echo -e "  ${C_WARN}⚠️  無 ipmi.conf,AC/DC 測試將會失敗${C_RESET}"
        fi
    fi

    echo ""
    echo -e "${C_INFO}════════════════════════════════════════${C_RESET}"
    echo -e "${C_PASS}下一步:${C_RESET}"
    echo -e "  執行命令: ${C_WARN}sudo bash regression_test.sh${C_RESET}"
    echo ""
    echo -e "${C_PASS}維運指令:${C_RESET}"
    echo -e "  查狀態  : ${C_WARN}sudo bash regression_test.sh --status${C_RESET}"
    echo -e "  中止測試: ${C_WARN}sudo bash regression_test.sh --abort${C_RESET}"
    echo ""
    echo -e "${C_ERROR}⚠️  重要警告:${C_RESET}"
    echo "  • 一旦開始測試,系統將自動進行多次重啟/關機操作"
    echo "  • 所有未保存的工作將遺失!"
    echo "  • 請確保所有重要資料已保存!"
    echo "  • 測試過程中請不要中斷電源"
    echo -e "${C_INFO}════════════════════════════════════════${C_RESET}"
    echo ""
}

# ==============================================================================
# Main
# ==============================================================================

main() {
    clear

    echo -e "${C_INFO}╔══════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_INFO}║  ${SCRIPT_NAME} v${SCRIPT_VERSION}        ║${C_RESET}"
    echo -e "${C_INFO}║  v5.0 Architecture - IPMI Auto-Config        ║${C_RESET}"
    echo -e "${C_INFO}╚══════════════════════════════════════════════╝${C_RESET}"
    echo ""

    # Phase 1: Pre-flight
    log_info "執行環境檢查..."
    check_root
    check_rhel_version
    check_disk_space
    echo ""

    # Phase 2: Cleanup (preserves ipmi.conf)
    log_info "開始測試配置..."
    cleanup_old_configs
    initialize_config_dir

    # Phase 3: Test type selection
    echo ""
    echo -e "${C_INFO}═══════════ 請選擇要執行的測試項目 ═══════════${C_RESET}"
    configure_reboot_test
    configure_ac_test
    configure_dc_test
    configure_shutdown_test

    # Phase 4: IPMI (only if AC or DC selected)
    configure_ipmi || true   # 配置失敗不阻斷流程,只是警告

    # Phase 5: Error policy
    configure_error_policy

    # Summary
    display_summary
}

main "$@"
