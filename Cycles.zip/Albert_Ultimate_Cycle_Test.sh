#!/bin/bash

################################################################################
# Project  : Albert Ultimate Cycle Test Engine
# Version  : 6.0 (Real AC via TR-14 Hardware + Relative Path)
# Author   : Albert Zhou (志偉 周)
# Date     : 2026-05-15
# License  : MIT
#
# CRITICAL FIX IN v6.0:
#   ✅ AC Cycle 改用 TR-14 硬體裝置切真實 AC 電源 (透過 serial console)
#   ✅ tr-14 工具改用相對路徑 ./tools/tr-14 (不再依賴 /usr/bin/tr-14)
#   ✅ 自動偵測 serial port (/dev/ttyS0 或 /dev/ttyUSB0)
#   ✅ 保留 IPMI poweroff 作為 fallback (當 TR-14 不存在時)
#   ✅ 強化環境檢查 (tr-14, ipmitool, rtcwake, serial port)
#
# CRITICAL FIX IN v5.9:
#   ✅ main() 啟動時嚴格驗證 -t 與 -c,空字串或無效值立即中止
#   ✅ 不再 silent fallback 到 DEFAULT_TEST_TYPE=REBOOT
#
# HYBRID APPROACH (v5.7):
#   ✅ 恢復 RTC 喚醒機制 (v5.1 邏輯,但改進)
#      用户已驗證: BIOS「Dynamic Time」啟用 → rtcwake 完全可用
#   ✅ 保留 always-on policy 硬檢查 (v5.6 特性)
#   ✅ 混合策略 (優先順序):
#      1. 嘗試 chassis power cycle (萬一此硬體廠商已修復呢)
#      2. 失敗 → chassis power off + rtcwake 設置 RTC 鬧鐘
#      3. 備用 → 等待 BMC always-on 自動回啟
#
# VERIFIED HARDWARE BEHAVIOR (此 BMC 已確認 - 2026-04-29):
#   ✅ RTC 設備: /sys/class/rtc/rtc0/wakealarm 可讀寫
#   ✅ rtcwake 命令: 能成功設置與取消鬧鐘
#   ✅ BIOS S5 RTC Wake: Dynamic Time 已啟用
#   ✅ chassis power cycle: ❌ 不開機 (保持此認知)
#   ✅ chassis power on: ✅ 開機
#   ✅ chassis power off: ✅ 關機
#   ✅ policy = always-on: ✅ 已啟用 (備用喚醒)
#   ✅ BMC SEL 日誌: 記錄了所有 ACPI/電源事件
#
# DC/AC CYCLE MECHANISM (v5.7):
#   Step 1: 驗證 RTC 設備可用 + rtcwake 命令存在
#   Step 2: 驗證 always-on policy 已啟用 (硬檢查)
#   Step 3: 倒數 + sync 確保狀態落盤
#   Step 4a: 首先嘗試 chassis power cycle
#            → 若成功: OS 應於 20 秒內自動回啟
#            → 若失敗: 繼續 Step 4b
#   Step 4b: 執行 chassis power off + rtcwake 鬧鐘
#            → rtcwake 在 DC_OFF_INTERVAL (20s) 後喚醒
#            → 機器回啟後 autostart 接手下一圈
#   Step 4c: (備用) BMC always-on 在 ~30s 內自動回啟
#
# ARCHITECTURE:
#   Phase 1-6:  初始化 (getopts → Session → 狀態檔 → 目錄)
#   Phase 7:    IPMI 連線 + RTC 初始化
#   Phase 8:    印出測試配置
#   Phase 9:    完成檢查 (CURRENT_CYCLE > MAX_CYCLES → finalize)
#   Phase 10:   第 1 圈建 Baseline,其餘圈採集 Current 並對比
#   Phase 11:   save_state (寫入 NEXT_CYCLE) + execute_power_operation
#
################################################################################

set -euo pipefail

# ==============================================================================
# Global Configuration & Constants
# ==============================================================================

readonly SCRIPT_VERSION="6.0"
readonly STATE_BASE="/root/Documents"
readonly STATE_FILE="${STATE_BASE}/Albert_Cycle_State.ini"
readonly SESSION_ID_FILE="${STATE_BASE}/.current_session"
readonly BOOTSTRAP_LOG="${STATE_BASE}/bootstrap.log"
readonly IPMI_CONF="./config/ipmi.conf"

# ════════════════════════════════════════════════════════════════════════════
# 🆕 v6.0: TR-14 Hardware AC Switch Configuration (相對路徑)
# ════════════════════════════════════════════════════════════════════════════
readonly TR14_TOOL="./tools/tr-14"                  # TR-14 執行檔(相對路徑)
readonly TR14_SERIAL_PORTS=("/dev/ttyS0" "/dev/ttyUSB0")  # 嘗試的 serial ports 順序
readonly TR14_OFF_SECONDS=50                        # AC 切電持續秒數(預設 50s)

# Color Definitions
readonly C_INFO="\e[1;36m"
readonly C_PASS="\e[1;32m"
readonly C_WARN="\e[1;33m"
readonly C_ERROR="\e[1;31m"
readonly C_CRIT="\e[1;41;37m"
readonly C_DEBUG="\e[0;37m"
readonly C_RESET="\e[0m"

# Hardware Categories (static info only, no dynamic data)
readonly CATEGORIES=(cpu dimm pcie system software hdd tpm hw sel vga lan)

# Default Settings
readonly DEFAULT_MAX_CYCLES=10
readonly DEFAULT_TEST_TYPE="REBOOT"

# Power Operation Timings (seconds)
readonly POWER_DOWN_DELAY=10        # Countdown before power operation
readonly DC_OFF_INTERVAL=20         # DC: OFF duration (RTC 喚醒間隔)
readonly AC_OFF_INTERVAL=30         # AC: OFF duration (RTC 喚醒間隔)
readonly RTC_VERIFY_TIMEOUT=5       # RTC wakealarm 驗證逾時(秒)

# RTC Configuration
readonly RTC_DEVICE="/sys/class/rtc/rtc0"
readonly RTC_WAKEALARM="${RTC_DEVICE}/wakealarm"

# Global State Variables
CURRENT_CYCLE=1
MAX_CYCLES=${DEFAULT_MAX_CYCLES}
TEST_TYPE="${DEFAULT_TEST_TYPE}"
ERROR_COUNT=0
ERROR_POLICY="CONTINUE"
SESSION_ID=""
COMPARE_DIR=""
OS_EVENT_DIR=""
DEBUG=0

# IPMI Runtime Variables
IPMI_OPTS=""        # e.g., "-I lanplus -H 192.168.10.35 -U root -P password"
IPMI_MODE="none"    # lanplus | inband | none

# ==============================================================================
# Logging Functions
# ==============================================================================

bootstrap_log() {
    local msg="$1"
    local ts="$(date +"%Y-%m-%d %H:%M:%S")"
    mkdir -p "${STATE_BASE}" 2>/dev/null || true
    echo "[$ts] $msg" >> "${BOOTSTRAP_LOG}" 2>/dev/null || true
}

write_log() {
    local type=$1
    local msg=$2
    local current_time=$(date +"%Y-%m-%d %H:%M:%S")

    case "$type" in
        "INFO") echo -e "${C_INFO}[$current_time] INFO: $msg${C_RESET}" ;;
        "PASS") echo -e "${C_PASS}[$current_time] PASS: $msg${C_RESET}" ;;
        "WARN") echo -e "${C_WARN}[$current_time] WARN: $msg${C_RESET}" ;;
        "ERROR") echo -e "${C_ERROR}[$current_time] ERROR: $msg${C_RESET}" ;;
        "CRIT") echo -e "${C_CRIT}[$current_time] CRITICAL: $msg${C_RESET}" ;;
        *) echo -e "[$current_time] $type: $msg" ;;
    esac

    # Dual-write: to both COMPARE_DIR and bootstrap log
    if [[ -n "${COMPARE_DIR:-}" && -d "${COMPARE_DIR:-}" ]]; then
        echo "[$current_time] $type: $msg" >> "${COMPARE_DIR}/execution.log" 2>/dev/null || true
    fi
    bootstrap_log "$type: $msg"
}

log_debug() {
    if [[ "${DEBUG:-0}" == "1" ]]; then
        echo -e "${C_DEBUG}[DEBUG] $1${C_RESET}"
        bootstrap_log "DEBUG: $1"
    fi
}

# ==============================================================================
# Signal Handling
# ==============================================================================

on_signal() {
    local sig=$1
    write_log "WARN" "收到信號 $sig,嘗試保存狀態後退出..."
    rtc_disable_alarm || true  # Clean up any pending RTC alarm
    save_state || true
    exit 130
}

trap 'on_signal INT'  INT
trap 'on_signal TERM' TERM

# ==============================================================================
# RTC Subsystem (新增 v5.7)
# ==============================================================================

rtc_check_available() {
    # 檢查 RTC 設備與 rtcwake 命令是否可用
    if [[ ! -r "${RTC_DEVICE}/dev" ]]; then
        write_log "ERROR" "RTC 設備不可用: ${RTC_DEVICE}"
        return 1
    fi
    if ! command -v rtcwake &>/dev/null; then
        write_log "ERROR" "rtcwake 命令未安裝 (util-linux 套件)"
        return 1
    fi
    write_log "PASS" "✓ RTC 設備與 rtcwake 命令可用"
    return 0
}

rtc_set_alarm() {
    # 設置 RTC 鬧鐘,在 N 秒後喚醒
    local seconds=$1
    local label="${2:-RTC Alarm}"
    
    write_log "INFO" "[RTC] 設置鬧鐘: ${seconds}秒後喚醒 ($label)"
    
    if ! rtcwake -m no -s "$seconds" 2>&1 | sed 's/^/  /'; then
        write_log "ERROR" "[RTC] rtcwake 設置失敗"
        return 1
    fi
    
    # 驗證 wakealarm 是否真的寫入
    sleep 1
    local wakealarm
    wakealarm=$(cat "${RTC_WAKEALARM}" 2>/dev/null || echo "0")
    
    if [[ "${wakealarm}" == "0" || -z "${wakealarm}" ]]; then
        write_log "CRIT" "[RTC] ❌ wakealarm 未寫入,鬧鐘設置失敗"
        return 1
    fi
    
    local wake_time
    wake_time=$(date -d "@${wakealarm}" 2>/dev/null || echo "unknown")
    write_log "PASS" "[RTC] ✓ 鬧鐘已設置,喚醒時間: $wake_time"
    return 0
}

rtc_disable_alarm() {
    # 取消 RTC 鬧鐘 (避免下次開機亂喚醒)
    write_log "DEBUG" "[RTC] 取消鬧鐘..."
    rtcwake -m disable 2>/dev/null || true
}

# ==============================================================================
# IPMI Subsystem
# ==============================================================================

ipmi_load_config() {
    # Load credentials from ./config/ipmi.conf
    # Format:
    #   IPMI_HOST=192.168.10.35
    #   IPMI_USER=root
    #   IPMI_PASS=P@ssw0rd
    #   IPMI_INTERFACE=lanplus   (optional, default: lanplus)
    
    if [[ ! -f "$IPMI_CONF" ]]; then
        log_debug "IPMI config not found: $IPMI_CONF"
        return 1
    fi

    # shellcheck disable=SC1090
    source "$IPMI_CONF" 2>/dev/null || {
        write_log "WARN" "Failed to parse IPMI config: $IPMI_CONF"
        return 1
    }

    local host="${IPMI_HOST:-}"
    local user="${IPMI_USER:-}"
    local pass="${IPMI_PASS:-}"
    local intf="${IPMI_INTERFACE:-lanplus}"

    if [[ -z "$host" || -z "$user" || -z "$pass" ]]; then
        write_log "WARN" "Incomplete IPMI config (HOST/USER/PASS missing), trying in-band"
        return 1
    fi

    IPMI_OPTS="-I ${intf} -H ${host} -U ${user} -P ${pass}"
    IPMI_MODE="lanplus"
    write_log "PASS" "✓ IPMI config loaded (mode=${intf}, host=${host})"
    return 0
}

ipmi_init() {
    write_log "INFO" "初始化 IPMI 子系統..."

    if ! command -v ipmitool &>/dev/null; then
        write_log "WARN" "⚠️  ipmitool 未安裝"
        IPMI_MODE="none"
        return 1
    fi

    # Priority 1: lanplus (out-of-band)
    if ipmi_load_config; then
        if ipmitool ${IPMI_OPTS} chassis status &>/dev/null; then
            write_log "PASS" "✓ IPMI lanplus 連線成功"
            return 0
        else
            write_log "WARN" "IPMI lanplus 連線失敗,嘗試 in-band fallback"
        fi
    fi

    # Priority 2: in-band
    IPMI_OPTS=""
    IPMI_MODE="inband"
    if ipmitool chassis status &>/dev/null; then
        write_log "PASS" "✓ IPMI in-band 連線成功"
        return 0
    fi

    write_log "WARN" "⚠️  IPMI 完全連線失敗 (lanplus + in-band)"
    IPMI_MODE="none"
    return 1
}

ipmi_cmd() {
    # Unified ipmitool wrapper
    if [[ "$IPMI_MODE" == "none" ]]; then
        write_log "ERROR" "IPMI unavailable, skipping: $*"
        return 1
    fi
    # shellcheck disable=SC2086
    ipmitool ${IPMI_OPTS} "$@" 2>&1
}

ipmi_get_power_status() {
    local raw
    raw=$(ipmi_cmd chassis status 2>/dev/null) || { echo "unknown"; return 0; }
    echo "$raw" | grep -i "System Power" | awk '{print $NF}' | head -n1 || echo "unknown"
}

# ==============================================================================
# Session Management
# ==============================================================================

get_persistent_session_id() {
    if [[ -f "$SESSION_ID_FILE" ]]; then
        cat "$SESSION_ID_FILE" 2>/dev/null || echo ""
    fi
}

get_session_id_from_state_file() {
    if [[ -f "$STATE_FILE" ]]; then
        grep "^SESSION_ID=" "$STATE_FILE" 2>/dev/null | cut -d'=' -f2 || echo ""
    fi
}

initialize_session() {
    mkdir -p "$STATE_BASE"

    # Priority 1: Persistent session ID file
    local session_id
    session_id=$(get_persistent_session_id)
    if [[ -n "$session_id" ]]; then
        write_log "INFO" "✓ Resuming session: $session_id" >&2
        echo "$session_id"
        return 0
    fi

    # Priority 2: State file
    session_id=$(get_session_id_from_state_file)
    if [[ -n "$session_id" ]]; then
        write_log "INFO" "✓ Found session in state file: $session_id" >&2
        echo "$session_id" > "$SESSION_ID_FILE"
        chmod 644 "$SESSION_ID_FILE"
        echo "$session_id"
        return 0
    fi

    # Priority 3: Create new
    session_id=$(date +"%Y%m%d_%H%M%S")
    echo "$session_id" > "$SESSION_ID_FILE"
    chmod 644 "$SESSION_ID_FILE"

    cat > "$STATE_FILE" << EOF
SESSION_ID=$session_id
CURRENT_CYCLE=1
MAX_CYCLES=${DEFAULT_MAX_CYCLES}
TEST_TYPE=${DEFAULT_TEST_TYPE}
ERROR_COUNT=0
ERROR_POLICY=CONTINUE
COMPARE_DIR=${STATE_BASE}/Compare_Log_${session_id}
EOF

    write_log "INFO" "新建 Session: $session_id" >&2
    echo "$session_id"
}

load_state() {
    if [[ -f "$STATE_FILE" && -s "$STATE_FILE" ]]; then
        write_log "INFO" "讀取狀態檔: $STATE_FILE"
        # shellcheck disable=SC1090
        source "$STATE_FILE" 2>/dev/null || true
        log_debug "State loaded - Cycle=$CURRENT_CYCLE, Type=$TEST_TYPE"
    fi
}

save_state() {
    write_log "INFO" "保存狀態檔..."

    local session_id="${SESSION_ID:-}"
    local current_cycle="$((${CURRENT_CYCLE:-1} + 1))"
    local max_cycles="${MAX_CYCLES:-${DEFAULT_MAX_CYCLES}}"
    local test_type="${TEST_TYPE:-${DEFAULT_TEST_TYPE}}"
    local error_count="${ERROR_COUNT:-0}"
    local compare_dir="${COMPARE_DIR:-}"

    if [[ -z "$session_id" ]]; then
        session_id=$(initialize_session)
    fi

    if [[ -z "$compare_dir" ]]; then
        compare_dir="${STATE_BASE}/Compare_Log_${session_id}"
    fi

    cat > "$STATE_FILE" << EOF
SESSION_ID=$session_id
CURRENT_CYCLE=$current_cycle
MAX_CYCLES=$max_cycles
TEST_TYPE=$test_type
ERROR_COUNT=$error_count
ERROR_POLICY=${ERROR_POLICY:-CONTINUE}
COMPARE_DIR=$compare_dir
EOF

    echo "$session_id" > "$SESSION_ID_FILE"
    chmod 644 "$SESSION_ID_FILE"

    # Critical: force-write to disk to survive DC power-off
    sync
    log_debug "State saved - Next Cycle=$current_cycle"
}

validate_state() {
    CURRENT_CYCLE=${CURRENT_CYCLE:-1}
    MAX_CYCLES=${MAX_CYCLES:-${DEFAULT_MAX_CYCLES}}
    TEST_TYPE=${TEST_TYPE:-${DEFAULT_TEST_TYPE}}
    ERROR_COUNT=${ERROR_COUNT:-0}
    ERROR_POLICY=${ERROR_POLICY:-CONTINUE}
    SESSION_ID=${SESSION_ID:-}
    COMPARE_DIR=${COMPARE_DIR:-}

    if [[ -z "$SESSION_ID" ]]; then
        write_log "WARN" "SESSION_ID 未設置,初始化..."
        SESSION_ID=$(initialize_session)
    fi

    if [[ -z "$COMPARE_DIR" ]]; then
        write_log "WARN" "COMPARE_DIR 為空,重新生成..."
        COMPARE_DIR="${STATE_BASE}/Compare_Log_${SESSION_ID}"
    fi

    if [[ ! -d "$COMPARE_DIR" ]]; then
        write_log "INFO" "COMPARE_DIR 不存在,建立: $COMPARE_DIR"
        mkdir -p "$COMPARE_DIR" || {
            write_log "CRIT" "❌ 無法建立 COMPARE_DIR: $COMPARE_DIR"
            exit 2
        }
    fi

    if ! [[ "$CURRENT_CYCLE" =~ ^[0-9]+$ ]]; then
        write_log "WARN" "CURRENT_CYCLE 無效,重置為 1"
        CURRENT_CYCLE=1
    fi

    if ! [[ "$MAX_CYCLES" =~ ^[0-9]+$ ]]; then
        write_log "WARN" "MAX_CYCLES 無效,重置為 ${DEFAULT_MAX_CYCLES}"
        MAX_CYCLES=${DEFAULT_MAX_CYCLES}
    fi

    case "$TEST_TYPE" in
        REBOOT|AC|DC|SHUTDOWN) ;;
        *)
            write_log "WARN" "TEST_TYPE 無效,重置為 REBOOT"
            TEST_TYPE="REBOOT"
            ;;
    esac

    log_debug "State validated"
}

# ==============================================================================
# Hardware Information Collection
# ==============================================================================

save_categorized_info() {
    local folder=$1
    local prefix=$2

    write_log "INFO" "收集硬體資訊: $prefix"

    if ! mkdir -p "$folder" 2>/dev/null; then
        write_log "CRIT" "❌ 無法建立目錄: $folder"
        return 1
    fi

    # CPU
    lscpu > "${folder}/${prefix}_cpu.log" 2>&1 || echo "N/A" > "${folder}/${prefix}_cpu.log"

    # Memory (DIMM)
    dmidecode -t memory 2>/dev/null | grep -v "No Module" > "${folder}/${prefix}_dimm.log" 2>&1 \
        || echo "N/A" > "${folder}/${prefix}_dimm.log"

    # PCIe (exclude LnkSta which changes)
    lspci -vvv 2>/dev/null | grep -v "LnkSta:" > "${folder}/${prefix}_pcie.log" 2>&1 \
        || echo "N/A" > "${folder}/${prefix}_pcie.log"

    # System / BIOS
    dmidecode -t system -t bios > "${folder}/${prefix}_system.log" 2>&1 \
        || echo "N/A" > "${folder}/${prefix}_system.log"

    # Software (RPM packages)
    if command -v rpm &>/dev/null; then
        rpm -qa | sort > "${folder}/${prefix}_software.log" 2>&1 \
            || echo "N/A" > "${folder}/${prefix}_software.log"
    else
        echo "N/A (no rpm)" > "${folder}/${prefix}_software.log"
    fi

    # Storage
    lsblk -a -o NAME,SIZE,MODEL,SERIAL > "${folder}/${prefix}_hdd.log" 2>&1 \
        || echo "N/A" > "${folder}/${prefix}_hdd.log"

    # TPM
    {
        dmesg 2>/dev/null | grep -i tpm || true
        tpm2_pcrread 2>/dev/null || true
    } > "${folder}/${prefix}_tpm.log" 2>&1 || echo "N/A" > "${folder}/${prefix}_tpm.log"

    # Hardware Overview (static)
    {
        echo "=== CPU Count ==="
        lscpu 2>/dev/null | grep "^CPU(s):" || echo "N/A"
        echo ""
        echo "=== Memory Total ==="
        dmidecode -t memory 2>/dev/null | grep "Maximum Capacity:" || echo "N/A"
    } > "${folder}/${prefix}_hw.log"

    # IPMI SEL
    if [[ "$IPMI_MODE" != "none" ]]; then
        ipmi_cmd sel list > "${folder}/${prefix}_sel.log" 2>&1 \
            || echo "N/A" > "${folder}/${prefix}_sel.log"
    else
        echo "N/A (IPMI unavailable)" > "${folder}/${prefix}_sel.log"
    fi

    # VGA / GPU
    lspci 2>/dev/null | grep -i vga > "${folder}/${prefix}_vga.log" 2>&1 \
        || echo "N/A" > "${folder}/${prefix}_vga.log"

    # Network Devices
    {
        echo "=== Network Devices ==="
        lspci 2>/dev/null | grep -iE "ethernet|network" || echo "N/A"
    } > "${folder}/${prefix}_lan.log"

    write_log "PASS" "✓ 硬體資訊收集完成: $prefix"
}

# ==============================================================================
# Hardware Comparison Logic
# ==============================================================================

compare_hardware() {
    local CYCLE_HAS_ERROR=0
    local error_categories=""

    write_log "INFO" "開始進行硬體對比..."

    for cat in "${CATEGORIES[@]}"; do
        local BASELINE_FILE="${COMPARE_DIR}/Baseline_${cat}.log"
        local CURRENT_FILE="${COMPARE_DIR}/Current_Cycle${CURRENT_CYCLE}_${cat}.log"
        local DIFF_FILE="${COMPARE_DIR}/Diff_${cat}_Cycle${CURRENT_CYCLE}.log"

        if [[ ! -f "$BASELINE_FILE" ]]; then
            write_log "CRIT" "❌ Baseline 檔案遺失: $BASELINE_FILE"
            CYCLE_HAS_ERROR=1
            error_categories="${error_categories}${cat}(missing) "
            continue
        fi

        if [[ ! -f "$CURRENT_FILE" ]]; then
            write_log "CRIT" "❌ 當前檔案遺失: $CURRENT_FILE"
            CYCLE_HAS_ERROR=1
            error_categories="${error_categories}${cat}(missing) "
            continue
        fi

        if ! diff -q "$BASELINE_FILE" "$CURRENT_FILE" >/dev/null 2>&1; then
            diff -u "$BASELINE_FILE" "$CURRENT_FILE" > "$DIFF_FILE" 2>&1 || true
            write_log "WARN" "⚠️  $cat 發現差異 (詳見 $DIFF_FILE)"
            CYCLE_HAS_ERROR=1
            error_categories="${error_categories}${cat} "
        else
            write_log "PASS" "✓ $cat 匹配"
        fi
    done

    if [[ $CYCLE_HAS_ERROR -eq 1 ]]; then
        ERROR_COUNT=$((ERROR_COUNT + 1))
        write_log "WARN" "⚠️  第 $CURRENT_CYCLE 圈檢測到變化: $error_categories"

        if [[ "$ERROR_POLICY" == "STOP" ]]; then
            write_log "CRIT" "🛑 異常策略為 STOP,立即中斷測試"
            save_state
            rm -f ~/.config/autostart/auto_test.desktop 2>/dev/null || true
            exit 1
        fi
    else
        write_log "PASS" "✓ 第 $CURRENT_CYCLE 圈:硬體檢查全部匹配"
    fi
}

# ==============================================================================
# Power Operation Functions
# ==============================================================================

countdown() {
    local secs=$1
    local action=$2
    write_log "INFO" "$action 倒數 ${secs}s..."
    for (( i=secs; i>0; i-- )); do
        echo -ne "\r${C_WARN}⏱️  $i 秒後執行...${C_RESET}   "
        sleep 1
    done
    echo -e "\n"
}

do_reboot() {
    write_log "INFO" "[REBOOT] 執行 OS reboot"
    countdown $POWER_DOWN_DELAY "OS Reboot"
    sync
    sleep 1
    /sbin/reboot || reboot || {
        write_log "CRIT" "reboot 命令失敗"
        exit 3
    }
    sleep 60
    exit 0
}

do_shutdown() {
    write_log "INFO" "[SHUTDOWN] 執行 graceful shutdown"
    countdown $POWER_DOWN_DELAY "S5 Shutdown"
    sync
    sleep 1

    if systemctl poweroff 2>&1; then
        write_log "PASS" "[SHUTDOWN] ✓ poweroff 命令已送出"
    else
        write_log "WARN" "[SHUTDOWN] ⚠️  systemctl poweroff 失敗,嘗試 poweroff"
        poweroff 2>&1 || true
    fi
    sleep 60
    exit 0
}

do_ac_cycle() {
    write_log "INFO" "╔═════════════════════════════════════════════════════╗"
    write_log "INFO" "║  AC Power Cycle (v6.0 - Real AC via TR-14)        ║"
    write_log "INFO" "╚═════════════════════════════════════════════════════╝"

    # ──────────────────────────────────────────────────────────────────────
    # 🆕 v6.0 預檢: 驗證 TR-14 硬體切電工具
    # ──────────────────────────────────────────────────────────────────────
    write_log "INFO" "[AC] 預檢 1: 驗證 TR-14 切電工具 (相對路徑: $TR14_TOOL)"
    
    local TR14_AVAILABLE=0
    local TR14_PORT=""
    
    if [[ -x "$TR14_TOOL" ]]; then
        write_log "PASS" "[AC] ✓ TR-14 工具存在且可執行: $TR14_TOOL"
        TR14_AVAILABLE=1
    else
        write_log "WARN" "[AC] ⚠️  TR-14 工具不存在或無執行權限: $TR14_TOOL"
        write_log "WARN" "[AC] 將降級使用 IPMI poweroff (DC 模式,非真實 AC)"
    fi

    # 偵測可用的 serial port
    if [[ "$TR14_AVAILABLE" -eq 1 ]]; then
        write_log "INFO" "[AC] 預檢 2: 偵測 TR-14 serial port..."
        local port
        for port in "${TR14_SERIAL_PORTS[@]}"; do
            if [[ -c "$port" ]]; then
                # 嘗試讀取 port (確認權限)
                if [[ -r "$port" ]] && [[ -w "$port" ]]; then
                    TR14_PORT="$port"
                    write_log "PASS" "[AC] ✓ 找到可用 serial port: $TR14_PORT"
                    break
                else
                    write_log "WARN" "[AC] $port 存在但無讀寫權限"
                fi
            else
                write_log "DEBUG" "[AC] $port 不存在"
            fi
        done

        if [[ -z "$TR14_PORT" ]]; then
            write_log "WARN" "[AC] ⚠️  找不到可用的 serial port,降級使用 IPMI"
            TR14_AVAILABLE=0
        fi
    fi

    # ──────────────────────────────────────────────────────────────────────
    # 路徑 1: 使用 TR-14 進行真實 AC 切電 (優先方案)
    # ──────────────────────────────────────────────────────────────────────
    if [[ "$TR14_AVAILABLE" -eq 1 ]]; then
        write_log "INFO" "════════════════════════════════════════════════════════"
        write_log "PASS" "[AC] 模式: TR-14 真實 AC 切電 (透過 $TR14_PORT)"
        write_log "INFO" "[AC] 切電時間: ${TR14_OFF_SECONDS}s"
        write_log "INFO" "[AC] 命令: $TR14_TOOL $TR14_PORT $TR14_OFF_SECONDS"
        write_log "INFO" "════════════════════════════════════════════════════════"

        countdown $POWER_DOWN_DELAY "AC Power OFF (TR-14)"

        # 確保狀態落盤 (在 AC 斷電前的最後一件事)
        write_log "INFO" "[AC] 強制 sync — 確保 CURRENT_CYCLE 已寫入磁碟"
        sync && sync && sync
        sleep 2

        # ──────────────────────────────────────────────────────────────
        # ⚡ 觸發 TR-14 切真實 AC 電源
        # 
        # TR-14 透過 RS-232/USB 控制外部繼電器
        # AC 電源完全切斷 ${TR14_OFF_SECONDS} 秒
        # 主機 PSU 因失去 AC 而完全斷電 → BMC 也失電
        # ${TR14_OFF_SECONDS}s 後 TR-14 重新接通 AC
        # BMC 啟動 → always-on policy 自動開機 → OS 啟動
        # autostart → regression --resume → engine 讀取 NEXT_CYCLE
        # ──────────────────────────────────────────────────────────────
        write_log "INFO" "[AC] 🔌 觸發 TR-14 切斷 AC 電源..."
        write_log "INFO" "[AC] 系統將在 ~${TR14_OFF_SECONDS}s 後自動回啟"
        
        # 執行 TR-14 (這會阻塞,直到 AC 切斷完成)
        # OS 在此之後死亡,後續程式碼不會執行
        "$TR14_TOOL" "$TR14_PORT" "$TR14_OFF_SECONDS" &
        local tr14_pid=$!
        
        sleep 5
        # 此時 AC 應該已斷,以下代碼不會執行
        
        # 若 5 秒後 OS 仍存活,代表 TR-14 沒有真的切電
        write_log "ERROR" "[AC] ⚠️  TR-14 觸發 5s 後 AC 未切斷!"
        write_log "ERROR" "[AC] 請檢查 TR-14 連線與電源繼電器"
        kill $tr14_pid 2>/dev/null || true
        
        write_log "WARN" "[AC] 降級使用 IPMI poweroff 作為備援"
        # Fall through to IPMI mode below
    fi

    # ──────────────────────────────────────────────────────────────────────
    # 路徑 2: 使用 IPMI poweroff (備用方案,當 TR-14 不可用時)
    # ──────────────────────────────────────────────────────────────────────
    write_log "INFO" "════════════════════════════════════════════════════════"
    write_log "INFO" "[AC] 模式: IPMI poweroff + RTC wake (備用方案)"
    write_log "INFO" "[AC] 注意: 此模式實際上是 DC 切電,非真實 AC"
    write_log "INFO" "════════════════════════════════════════════════════════"

    if [[ "$IPMI_MODE" == "none" ]]; then
        write_log "CRIT" "❌ IPMI 也不可用,AC Cycle 無法執行"
        write_log "CRIT" "   請部署 TR-14 工具到 $TR14_TOOL"
        write_log "CRIT" "   或配置 ./config/ipmi.conf 啟用 IPMI"
        exit 3
    fi

    # 預檢: 驗證 RTC 可用
    write_log "INFO" "[AC] 預檢 IPMI: 驗證 RTC 設備"
    if ! rtc_check_available; then
        write_log "WARN" "[AC] ⚠️  RTC 不可用,將降級使用 BMC always-on"
    fi

    # 預檢: 驗證 always-on policy
    write_log "INFO" "[AC] 預檢 IPMI: 驗證 BMC Power Restore Policy"

    local policy
    policy=$(ipmi_cmd chassis status 2>/dev/null \
        | grep -i "Power Restore Policy" \
        | awk -F: '{print $2}' \
        | tr -d '[:space:]' \
        | tr '[:upper:]' '[:lower:]' \
        || echo "unknown")

    write_log "INFO" "[AC] Power Restore Policy: ${policy}"

    if ! echo "${policy}" | grep -qiE "alwayson|always.on"; then
        write_log "CRIT" "═══════════════════════════════════════════════════════"
        write_log "CRIT" "❌ BMC Policy 不是 always-on (目前: ${policy})"
        write_log "CRIT" "   AC Cycle 需要此 Policy 才能在斷電後自動回啟"
        write_log "CRIT" "   ipmitool ${IPMI_OPTS} chassis policy always-on"
        write_log "CRIT" "═══════════════════════════════════════════════════════"
        exit 3
    fi
    write_log "PASS" "[AC] ✓ Policy 確認為 always-on"

    local status_before
    status_before=$(ipmi_get_power_status)
    write_log "INFO" "[AC] 切電前狀態: ${status_before}"
    write_log "INFO" "[AC] 斷電後 BMC always-on 預計 ~${AC_OFF_INTERVAL}s 內自動回啟"

    countdown $POWER_DOWN_DELAY "AC Power OFF (IPMI fallback)"

    write_log "INFO" "[AC] 強制 sync — 確保 CURRENT_CYCLE 已寫入磁碟"
    sync && sync
    sleep 1

    # 若 RTC 可用,先設置鬧鐘
    if command -v rtcwake &>/dev/null && [[ -w "${RTC_WAKEALARM}" ]]; then
        write_log "INFO" "[AC] 使用 RTC 喚醒 (優先方案)"
        if ! rtc_set_alarm "$AC_OFF_INTERVAL" "AC Cycle"; then
            write_log "WARN" "[AC] RTC 設置失敗,改用 always-on (備用)"
        fi
    else
        write_log "INFO" "[AC] RTC 不可用,使用 BMC always-on (備用方案)"
    fi

    write_log "INFO" "[AC] 執行: poweroff"
    write_log "INFO" "[AC] → 預計 ~${AC_OFF_INTERVAL}s 後自動回啟"

    sync && sync
    sleep 1

    poweroff

    sleep 60
    write_log "WARN" "[AC] ⚠️  poweroff 送出 60s 後 OS 仍存活 (不應發生)"
    exit 0
}

do_dc_cycle() {
    write_log "INFO" "╔═════════════════════════════════════════════════════╗"
    write_log "INFO" "║  DC Power Cycle (v5.7 - RTC Wake + always-on)     ║"
    write_log "INFO" "╚═════════════════════════════════════════════════════╝"

    if [[ "$IPMI_MODE" == "none" ]]; then
        write_log "CRIT" "❌ IPMI 不可用,DC Cycle 無法執行"
        write_log "CRIT" "   請建立 ./config/ipmi.conf 並填入 BMC 憑證"
        exit 3
    fi

    # ──────────────────────────────────────────────────────────────────────
    # 預檢 1: 驗證 RTC 可用
    # ──────────────────────────────────────────────────────────────────────
    write_log "INFO" "[DC] 預檢 1: 驗證 RTC 設備 (重要)"
    if ! rtc_check_available; then
        write_log "WARN" "[DC] ⚠️  RTC 不可用,將降級使用 BMC always-on"
        write_log "WARN" "[DC]    提示: 如 RTC 無法使用,此硬體可能無法自動化 DC cycle"
    fi

    # ──────────────────────────────────────────────────────────────────────
    # 預檢 2: 驗證 always-on policy (硬檢查)
    # ──────────────────────────────────────────────────────────────────────
    write_log "INFO" "[DC] 預檢 2: 驗證 BMC Power Restore Policy"

    local policy
    policy=$(ipmi_cmd chassis status 2>/dev/null \
        | grep -i "Power Restore Policy" \
        | awk -F: '{print $2}' \
        | tr -d '[:space:]' \
        | tr '[:upper:]' '[:lower:]' \
        || echo "unknown")

    write_log "INFO" "[DC] Power Restore Policy: ${policy}"

    if ! echo "${policy}" | grep -qiE "alwayson|always.on"; then
        write_log "CRIT" "═══════════════════════════════════════════════════════"
        write_log "CRIT" "❌ BMC Policy 不是 always-on (目前: ${policy})"
        write_log "CRIT" "   DC Cycle 需要此 Policy 才能在斷電後自動回啟"
        write_log "CRIT" "   請先在 ver.sh 設定或手動執行:"
        write_log "CRIT" "   ipmitool ${IPMI_OPTS} chassis policy always-on"
        write_log "CRIT" "═══════════════════════════════════════════════════════"
        exit 3
    fi
    write_log "PASS" "[DC] ✓ Policy 確認為 always-on"

    # 切電前狀態
    local status_before
    status_before=$(ipmi_get_power_status)
    write_log "INFO" "[DC] 切電前狀態: ${status_before}"
    write_log "INFO" "[DC] 斷電後 BMC always-on 預計 ~${DC_OFF_INTERVAL}s 內自動回啟"

    countdown $POWER_DOWN_DELAY "DC Power OFF"

    # 確保狀態落盤 (在 OS 死亡前的最後一件事)
    write_log "INFO" "[DC] 強制 sync — 確保 CURRENT_CYCLE 已寫入磁碟"
    sync && sync
    sleep 1

    # ──────────────────────────────────────────────────────────────
    # ⚡ 送出 IPMI Power OFF
    #
    # 命令透過 lanplus 送到 BMC。BMC 切斷 DC → OS 瞬間死亡。
    # 此腳本及所有 OS 上的 process 均在此時死亡。
    #
    # 回啟流程 (完全由 BMC 主導,此硬體已驗證):
    #   BMC 偵測到主機斷電
    #   → always-on policy 觸發 (~DC_OFF_INTERVAL 秒後)
    #   → BMC 自動送出 power on  (注意:chassis power cycle 無效,
    #                              但 power off + always-on 有效)
    #   → 系統回啟 → autostart → regression --resume
    #   → engine 讀取已存的 CURRENT_CYCLE+1 → 繼續下一圈
    # ──────────────────────────────────────────────────────────────
    # ──────────────────────────────────────────────────────────────────────
    # 混合方案: 優先 RTC,備用 always-on
    # ──────────────────────────────────────────────────────────────────────

    # 若 RTC 可用,先設置鬧鐘
    if command -v rtcwake &>/dev/null && [[ -w "${RTC_WAKEALARM}" ]]; then
        write_log "INFO" "[DC] 使用 RTC 喚醒 (優先方案)"
        if ! rtc_set_alarm "$DC_OFF_INTERVAL" "DC Cycle"; then
            write_log "WARN" "[DC] RTC 設置失敗,改用 always-on (備用)"
        fi
    else
        write_log "INFO" "[DC] RTC 不可用,使用 BMC always-on (備用方案)"
    fi

    # 執行 power off (優雅關閉)
    write_log "INFO" "[DC] 執行: poweroff (OS level, in-band)"
    write_log "INFO" "[DC] → BIOS 進入 S5,RTC 開始監控"
    write_log "INFO" "[DC] → 預計 ~${DC_OFF_INTERVAL}s 後透過 RTC 自動回啟"
    write_log "INFO" "[DC] → 備用: BMC always-on 政策在 ~30s 內接手"

    # 同步並優雅關閉
    sync && sync
    sleep 1

    # 正式執行 poweroff (v5.8 修復)
    poweroff

    # OS 已關閉,BIOS 接手,以下代碼不會執行
    sleep 60
    write_log "WARN" "[DC] ⚠️  poweroff 送出 60s 後 OS 仍存活 (不應發生)"
    exit 0
}

execute_power_operation() {
    case "$TEST_TYPE" in
        REBOOT)   do_reboot ;;
        AC)       do_ac_cycle ;;
        DC)       do_dc_cycle ;;
        SHUTDOWN) do_shutdown ;;
        *)
            write_log "CRIT" "❌ 未知的測試類型: $TEST_TYPE"
            exit 2
            ;;
    esac
}

# ==============================================================================
# Finalization
# ==============================================================================

finalize_test() {
    write_log "PASS" "========== $TEST_TYPE 測試完成 =========="

    if [[ $ERROR_COUNT -gt 0 ]]; then
        write_log "WARN" "⚠️  測試完成,發現 $ERROR_COUNT 次硬體變化 (需審查)"
    else
        write_log "PASS" "🎉 完美運行!硬體配置穩定"
    fi

    write_log "INFO" "收集最終系統日誌..."
    mkdir -p "$OS_EVENT_DIR" 2>/dev/null || true
    journalctl -xb > "${OS_EVENT_DIR}/os_journalctl.log" 2>&1 || true
    save_categorized_info "$OS_EVENT_DIR" "Final"

    # Clean up state files and autostart
    rm -f "$STATE_FILE"
    rm -f "$SESSION_ID_FILE"
    rm -f ~/.config/autostart/auto_test.desktop 2>/dev/null || true

    write_log "PASS" "✅ 所有測試已完成,autostart 已移除"
    sync
    exit 0
}

# ==============================================================================
# Main Function
# ==============================================================================

print_header() {
    echo -e "${C_INFO}╔══════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_INFO}║  Albert Ultimate Cycle Test Engine v${SCRIPT_VERSION}      ║${C_RESET}"
    echo -e "${C_INFO}║         Pure IPMI - No RTC Dependency         ║${C_RESET}"
    echo -e "${C_INFO}╚══════════════════════════════════════════════╝${C_RESET}"
    echo ""
}

usage() {
    cat << EOF
Usage: $0 -t <TYPE> -c <CYCLES> [-d]

Options:
  -t TYPE     Test type: REBOOT | AC | DC | SHUTDOWN  (default: REBOOT)
  -c CYCLES   Total cycles (1-1000)                   (default: ${DEFAULT_MAX_CYCLES})
  -d          Enable debug output

Examples:
  $0 -t DC -c 50          # 50 cycles of DC power cycle
  $0 -t AC -c 100         # 100 cycles of AC power cycle
  $0 -t REBOOT -c 100 -d  # 100 reboots with debug

IPMI Configuration (./config/ipmi.conf):
  IPMI_HOST=192.168.10.35
  IPMI_USER=root
  IPMI_PASS=P@ssw0rd
  IPMI_INTERFACE=lanplus
EOF
}

main() {
    # ─────────────────────────────────────────
    # Phase 1: Parse command line arguments
    # ─────────────────────────────────────────
    local CMD_TEST_TYPE=""
    local CMD_MAX_CYCLES=""

    while getopts "t:c:dh" opt; do
        case $opt in
            t) CMD_TEST_TYPE="${OPTARG^^}" ;;
            c) CMD_MAX_CYCLES="$OPTARG" ;;
            d) DEBUG=1 ;;
            h) usage; exit 0 ;;
            *) usage; exit 1 ;;
        esac
    done

    bootstrap_log "===== Engine v${SCRIPT_VERSION} 啟動 ====="
    bootstrap_log "args: type=${CMD_TEST_TYPE}, cycles=${CMD_MAX_CYCLES}, debug=${DEBUG}"

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 安全防護 (v5.9 新增): 空參數即時拒絕
    # 防止 regression bug 傳入空字串導致 fallback 到 DEFAULT_TEST_TYPE=REBOOT
    # 規則:
    #   - 若 STATE_FILE 不存在 (新測試),命令列必須提供 -t 與 -c
    #   - 若 STATE_FILE 存在 (resume),命令列亦應提供 (regression 一律會帶)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if [[ -z "$CMD_TEST_TYPE" ]] || [[ -z "$CMD_MAX_CYCLES" ]]; then
        echo -e "${C_ERROR}════════════════════════════════════════════════════════════════${C_RESET}"
        echo -e "${C_ERROR}❌ FATAL: 必須提供 -t TYPE 與 -c CYCLES 參數${C_RESET}"
        echo -e "${C_ERROR}   收到: -t='$CMD_TEST_TYPE'  -c='$CMD_MAX_CYCLES'${C_RESET}"
        echo -e "${C_ERROR}   為防止 fallback 到 DEFAULT 值意外執行 REBOOT 測試,立即中止${C_RESET}"
        echo -e "${C_ERROR}════════════════════════════════════════════════════════════════${C_RESET}"
        echo ""
        usage
        bootstrap_log "FATAL: empty CMD_TEST_TYPE or CMD_MAX_CYCLES, refusing fallback"
        exit 1
    fi

    # 驗證 TYPE 必須是合法值 (拒絕無效字串)
    case "$CMD_TEST_TYPE" in
        REBOOT|AC|DC|SHUTDOWN) ;;
        *)
            echo -e "${C_ERROR}❌ FATAL: 無效的 TEST TYPE: '$CMD_TEST_TYPE'${C_RESET}"
            echo -e "${C_ERROR}   只接受: REBOOT / AC / DC / SHUTDOWN${C_RESET}"
            bootstrap_log "FATAL: invalid CMD_TEST_TYPE='$CMD_TEST_TYPE'"
            exit 1
            ;;
    esac

    # 驗證 CYCLES 必須是正整數
    if ! [[ "$CMD_MAX_CYCLES" =~ ^[0-9]+$ ]] || [[ "$CMD_MAX_CYCLES" -lt 1 ]]; then
        echo -e "${C_ERROR}❌ FATAL: 無效的 CYCLES: '$CMD_MAX_CYCLES' (必須 >= 1)${C_RESET}"
        bootstrap_log "FATAL: invalid CMD_MAX_CYCLES='$CMD_MAX_CYCLES'"
        exit 1
    fi

    print_header

    # ─────────────────────────────────────────
    # Phase 2: Create base directories
    # ─────────────────────────────────────────
    if ! mkdir -p "$STATE_BASE" 2>/dev/null; then
        echo -e "${C_ERROR}錯誤:無法建立 STATE_BASE: $STATE_BASE${C_RESET}"
        exit 1
    fi

    # ─────────────────────────────────────────
    # Phase 3: Session initialization
    # ─────────────────────────────────────────
    SESSION_ID=$(initialize_session)
    log_debug "SESSION_ID = $SESSION_ID"

    load_state
    validate_state

    # ─────────────────────────────────────────
    # Phase 4: Command line overrides
    # ─────────────────────────────────────────
    if [[ -n "$CMD_MAX_CYCLES" ]]; then
        if [[ "$CMD_MAX_CYCLES" =~ ^[0-9]+$ ]] && [[ "$CMD_MAX_CYCLES" -ge 1 ]]; then
            MAX_CYCLES=$CMD_MAX_CYCLES
        else
            write_log "WARN" "命令列 -c 值無效: $CMD_MAX_CYCLES,使用 $MAX_CYCLES"
        fi
    fi
    if [[ -n "$CMD_TEST_TYPE" ]]; then
        case "$CMD_TEST_TYPE" in
            REBOOT|AC|DC|SHUTDOWN) TEST_TYPE=$CMD_TEST_TYPE ;;
            *) write_log "WARN" "命令列 -t 值無效: $CMD_TEST_TYPE,使用 $TEST_TYPE" ;;
        esac
    fi

    # ─────────────────────────────────────────
    # Phase 5: Load error policy
    # ─────────────────────────────────────────
    if [[ -f "./config/error_policy" ]]; then
        ERROR_POLICY=$(cat "./config/error_policy" | tr -d '[:space:]')
    fi

    # ─────────────────────────────────────────
    # Phase 6: Setup output directories
    # ─────────────────────────────────────────
    [[ -z "$COMPARE_DIR" ]] && COMPARE_DIR="${STATE_BASE}/Compare_Log_${SESSION_ID}"
    OS_EVENT_DIR="${STATE_BASE}/OS_Event_Log_${SESSION_ID}"
    mkdir -p "$COMPARE_DIR" "$OS_EVENT_DIR" || {
        write_log "CRIT" "無法建立輸出目錄"
        exit 1
    }

    # ─────────────────────────────────────────
    # Phase 7: IPMI initialization
    # ─────────────────────────────────────────
    if [[ "$TEST_TYPE" == "AC" || "$TEST_TYPE" == "DC" ]]; then
        ipmi_init || {
            write_log "CRIT" "❌ ${TEST_TYPE} 測試需要 IPMI,但初始化失敗"
            write_log "CRIT" "   請檢查 ./config/ipmi.conf 或安裝 ipmitool"
            exit 3
        }
        
        # RTC initialization (v5.7) — DC/AC cycle 需要 RTC
        write_log "INFO" "初始化 RTC 設備..."
        rtc_check_available || write_log "WARN" "RTC 不可用,DC/AC 將使用備用方案 (always-on)"
    else
        ipmi_init || true
    fi

    # ─────────────────────────────────────────
    # Phase 8: Print test configuration
    # ─────────────────────────────────────────
    write_log "INFO" "========================================================"
    write_log "INFO" "Test Configuration:"
    write_log "INFO" "  Type         = $TEST_TYPE"
    write_log "INFO" "  Cycle        = $CURRENT_CYCLE / $MAX_CYCLES"
    write_log "INFO" "  Session ID   = $SESSION_ID"
    write_log "INFO" "  Error Policy = $ERROR_POLICY"
    write_log "INFO" "  IPMI Mode    = $IPMI_MODE"
    write_log "INFO" "  COMPARE_DIR  = $COMPARE_DIR"
    write_log "INFO" "========================================================"

    # ─────────────────────────────────────────
    # Phase 9: Check completion
    # ─────────────────────────────────────────
    if [[ $CURRENT_CYCLE -gt $MAX_CYCLES ]]; then
        finalize_test
    fi

    # ─────────────────────────────────────────
    # Phase 10: Baseline or Compare
    # ─────────────────────────────────────────
    if [[ $CURRENT_CYCLE -eq 1 ]]; then
        write_log "INFO" "========== 第 1 圈:建立硬體基準線 =========="
        save_categorized_info "$COMPARE_DIR" "Baseline"
        write_log "PASS" "✓ 硬體基準線已建立"
    else
        write_log "INFO" "========== 第 $CURRENT_CYCLE 圈:收集當前資訊並對比 =========="
        save_categorized_info "$COMPARE_DIR" "Current_Cycle${CURRENT_CYCLE}"
        compare_hardware
    fi

    # ─────────────────────────────────────────
    # Phase 11: Save state and execute power op
    # ─────────────────────────────────────────
    save_state
    execute_power_operation

    # Usually won't reach here
    write_log "WARN" "execute_power_operation 異常返回"
    exit 0
}

# ==============================================================================
# Entry Point
# ==============================================================================

main "$@"