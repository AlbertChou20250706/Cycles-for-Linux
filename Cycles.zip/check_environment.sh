#!/bin/bash

################################################################################
# Albert SIT - 環境完整性檢查工具
# Version  : 1.0
# 用途     : 獨立執行的環境檢查 (不影響任何狀態,可隨時執行)
# 用法     : bash check_environment.sh
################################################################################

set -uo pipefail   # 不使用 -e，因為要繼續檢查即使有錯

# ==============================================================================
# Colors
# ==============================================================================
readonly C_INFO="\e[1;36m"
readonly C_PASS="\e[1;32m"
readonly C_WARN="\e[1;33m"
readonly C_ERROR="\e[1;31m"
readonly C_RESET="\e[0m"

log_info()  { echo -e "${C_INFO}[INFO]${C_RESET} $1"; }
log_pass()  { echo -e "${C_PASS}[PASS]${C_RESET} $1"; }
log_warn()  { echo -e "${C_WARN}[WARN]${C_RESET} $1"; }
log_error() { echo -e "${C_ERROR}[ERROR]${C_RESET} $1"; }

# ==============================================================================
# 計數器
# ==============================================================================
TOTAL_ERRORS=0
TOTAL_WARNINGS=0
HINTS=()

add_hint() {
    HINTS+=("$1")
}

# ==============================================================================
# 標題
# ==============================================================================
echo ""
echo -e "${C_INFO}╔════════════════════════════════════════════════════════════════╗${C_RESET}"
echo -e "${C_INFO}║   Albert SIT - 環境完整性檢查工具 v1.0                         ║${C_RESET}"
echo -e "${C_INFO}║   檢查所有必要的 packages 與工具                               ║${C_RESET}"
echo -e "${C_INFO}╚════════════════════════════════════════════════════════════════╝${C_RESET}"
echo ""

# ==============================================================================
# 1. 作業系統資訊
# ==============================================================================
log_info "═══════ 1. 作業系統資訊 ═══════"
echo ""

if [[ -f /etc/redhat-release ]]; then
    log_pass "  OS: $(cat /etc/redhat-release)"
elif [[ -f /etc/os-release ]]; then
    log_pass "  OS: $(grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"')"
else
    log_warn "  ⚠️  無法識別 OS"
    TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
fi

log_pass "  Kernel: $(uname -r)"
log_pass "  Architecture: $(uname -m)"

# 檢查 RHEL 版本
if [[ -f /etc/os-release ]]; then
    if grep -q "VERSION_ID=\"10" /etc/os-release; then
        log_pass "  ✓ RHEL 10 偵測成功 (使用 v5.3 + systemd autostart)"
    elif grep -q "VERSION_ID=\"9" /etc/os-release; then
        log_warn "  ⚠️  RHEL 9 偵測,建議升級到 RHEL 10 以獲得最佳支援"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi
fi

echo ""

# ==============================================================================
# 2. 核心 Linux 工具
# ==============================================================================
log_info "═══════ 2. 核心 Linux 工具 ═══════"
echo ""

CORE_TOOLS=(
    "bash:bash"
    "awk:gawk"
    "sed:sed"
    "grep:grep"
    "cut:coreutils"
    "tr:coreutils"
    "head:coreutils"
    "tail:coreutils"
    "sleep:coreutils"
    "mkdir:coreutils"
    "rm:coreutils"
    "cp:coreutils"
    "chmod:coreutils"
    "sync:coreutils"
    "date:coreutils"
)

missing_core=()
for tool_pkg in "${CORE_TOOLS[@]}"; do
    tool="${tool_pkg%%:*}"
    pkg="${tool_pkg##*:}"
    if command -v "$tool" &>/dev/null; then
        log_pass "  ✓ $tool"
    else
        log_error "  ❌ $tool 缺失 (來自 $pkg)"
        missing_core+=("$pkg")
        TOTAL_ERRORS=$((TOTAL_ERRORS + 1))
    fi
done

if [[ ${#missing_core[@]} -gt 0 ]]; then
    # 去重複
    unique_pkgs=$(echo "${missing_core[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' ')
    add_hint "dnf install -y $unique_pkgs"
fi

echo ""

# ==============================================================================
# 3. SIT 測試專用工具
# ==============================================================================
log_info "═══════ 3. SIT 測試工具 ═══════"
echo ""

SIT_TOOLS=(
    "ipmitool:ipmitool:AC/DC 測試必要"
    "dmidecode:dmidecode:硬體資訊採集"
    "lspci:pciutils:PCI 設備資訊"
    "lscpu:util-linux:CPU 資訊"
    "rtcwake:util-linux:DC/AC RTC 喚醒"
    "bc:bc:計算工具"
    "expect:expect:自動化互動"
    "zip:zip:結果打包"
    "journalctl:systemd:系統日誌"
    "systemctl:systemd:服務管理"
)

for entry in "${SIT_TOOLS[@]}"; do
    IFS=':' read -r tool pkg desc <<< "$entry"
    if command -v "$tool" &>/dev/null; then
        log_pass "  ✓ $tool ($desc)"
    else
        log_warn "  ⚠️  $tool 未安裝 ($desc) - 來自套件: $pkg"
        add_hint "dnf install -y $pkg"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi
done

echo ""

# ==============================================================================
# 4. systemd 環境檢查
# ==============================================================================
log_info "═══════ 4. systemd 環境 ═══════"
echo ""

if command -v systemctl &>/dev/null; then
    log_pass "  ✓ systemctl 可用"
    
    if [[ -d /run/systemd/system ]]; then
        log_pass "  ✓ systemd 為當前 init 系統"
    else
        log_warn "  ⚠️  系統未使用 systemd"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi
    
    # 檢查 systemd --user
    if systemctl --user list-unit-files &>/dev/null; then
        log_pass "  ✓ systemd --user 可用 (RHEL 10 autostart 支援)"
    else
        log_warn "  ⚠️  systemd --user 不可用,RHEL 10 autostart 可能失效"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi

    # 檢查是否有殘留的 albert-sit-resume.service
    if systemctl --user is-enabled albert-sit-resume.service &>/dev/null; then
        log_warn "  ⚠️  發現殘留的 albert-sit-resume.service (上次測試未完成?)"
        add_hint "systemctl --user disable albert-sit-resume.service"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi
fi

echo ""

# ==============================================================================
# 5. SIT 檔案結構
# ==============================================================================
log_info "═══════ 5. SIT 檔案結構檢查 ═══════"
echo ""

REQUIRED_FILES=(
    "regression_test.sh"
    "Albert_Ultimate_Cycle_Test.sh"
    "ver.sh"
)

OPTIONAL_FILES=(
    "stop_reboot_test.sh"
    "install.sh"
)

for f in "${REQUIRED_FILES[@]}"; do
    if [[ -f "$f" ]]; then
        if [[ -x "$f" ]]; then
            log_pass "  ✓ $f (可執行)"
        else
            log_warn "  ⚠️  $f (無執行權限)"
            add_hint "chmod 755 $f"
            TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
        fi
    else
        log_error "  ❌ $f 不存在 (必要)"
        TOTAL_ERRORS=$((TOTAL_ERRORS + 1))
    fi
done

for f in "${OPTIONAL_FILES[@]}"; do
    if [[ -f "$f" ]]; then
        log_pass "  ✓ $f (可選)"
    else
        log_info "  ⊘ $f 未提供 (可選)"
    fi
done

# 檢查 config 目錄
if [[ -d "config" ]]; then
    log_pass "  ✓ config/ 目錄存在"
    
    if [[ -f "config/ipmi.conf" ]]; then
        local perm
        perm=$(stat -c "%a" config/ipmi.conf 2>/dev/null)
        if [[ "$perm" == "600" ]]; then
            log_pass "  ✓ config/ipmi.conf 權限正確 (600)"
        else
            log_warn "  ⚠️  config/ipmi.conf 權限不安全 ($perm,應為 600)"
            add_hint "chmod 600 config/ipmi.conf"
            TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
        fi
    else
        log_info "  ⊘ config/ipmi.conf 未配置 (AC/DC 測試需要)"
    fi
else
    log_warn "  ⚠️  config/ 目錄不存在 (執行 ver.sh 會自動建立)"
    TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
fi

echo ""

# ==============================================================================
# 6. TR-14 工具檢查 (AC 真實切電)
# ==============================================================================
log_info "═══════ 6. TR-14 切電工具 (AC 真實電源) ═══════"
echo ""

TR14_PATH="./tools/tr-14"

if [[ -f "$TR14_PATH" ]]; then
    if [[ -x "$TR14_PATH" ]]; then
        log_pass "  ✓ TR-14 工具就位: $TR14_PATH"
        
        # 檢查檔案類型
        local file_info
        file_info=$(file "$TR14_PATH" 2>/dev/null)
        if echo "$file_info" | grep -q "ELF.*executable"; then
            log_pass "  ✓ 檔案類型: 二進位執行檔"
        fi
        
        # 檢查 serial port 可用性
        echo ""
        log_info "  檢查 serial port 可用性..."
        FOUND_PORT=""
        for port in /dev/ttyS0 /dev/ttyS1 /dev/ttyUSB0 /dev/ttyUSB1; do
            if [[ -c "$port" ]]; then
                if [[ -r "$port" ]] && [[ -w "$port" ]]; then
                    log_pass "  ✓ $port (可讀寫)"
                    FOUND_PORT="$port"
                else
                    log_warn "  ⚠️  $port (權限不足)"
                    add_hint "可能需要將使用者加入 dialout 群組: usermod -aG dialout root"
                fi
            fi
        done
        
        if [[ -z "$FOUND_PORT" ]]; then
            log_warn "  ⚠️  未偵測到可用的 serial port"
            log_warn "      AC 測試將降級使用 IPMI poweroff (非真實 AC)"
            add_hint "檢查 TR-14 連線 (USB/Serial 線材)"
            TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
        fi
    else
        log_warn "  ⚠️  TR-14 存在但無執行權限"
        add_hint "chmod 755 $TR14_PATH"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi
else
    log_warn "  ⚠️  TR-14 工具不存在: $TR14_PATH"
    log_warn "      AC 測試將降級使用 IPMI poweroff (非真實 AC)"
    add_hint "將 tr-14 二進位檔複製到: mkdir -p tools && cp tr-14 tools/ && chmod 755 tools/tr-14"
    TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
fi

echo ""

# ==============================================================================
# 7. RTC 喚醒裝置 (DC/AC fallback)
# ==============================================================================
log_info "═══════ 7. RTC 喚醒裝置 ═══════"
echo ""

if [[ -e /sys/class/rtc/rtc0 ]]; then
    log_pass "  ✓ /sys/class/rtc/rtc0 存在"
    
    if [[ -w /sys/class/rtc/rtc0/wakealarm ]]; then
        log_pass "  ✓ wakealarm 可寫"
    else
        log_warn "  ⚠️  wakealarm 不可寫 (需要 root)"
        TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
    fi
    
    # 檢查 BIOS 是否啟用 RTC Wake
    log_info "  💡 提示: 若 RTC 不工作,請在 BIOS 啟用 'Dynamic Time' 或 'S5 RTC Wake'"
else
    log_warn "  ⚠️  /sys/class/rtc/rtc0 不存在 (BIOS 可能未啟用 RTC)"
    add_hint "進入 BIOS 啟用 RTC Wake 功能"
    TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
fi

echo ""

# ==============================================================================
# 8. 磁碟空間
# ==============================================================================
log_info "═══════ 8. 磁碟空間 ═══════"
echo ""

ROOT_AVAIL=$(df /root 2>/dev/null | tail -1 | awk '{print $4}')
if [[ -n "$ROOT_AVAIL" ]] && [[ "$ROOT_AVAIL" -gt 1048576 ]]; then
    log_pass "  ✓ /root 可用空間: $((ROOT_AVAIL / 1024)) MB"
else
    log_warn "  ⚠️  /root 空間不足 1GB,可能無法存放完整 log"
    TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
fi

DOCS_AVAIL=$(df /root/Documents 2>/dev/null | tail -1 | awk '{print $4}')
if [[ -d /root/Documents ]]; then
    log_pass "  ✓ /root/Documents 存在"
else
    log_info "  ⊘ /root/Documents 不存在 (測試時會自動建立)"
fi

echo ""

# ==============================================================================
# 9. 殘留檔案檢查 (上次測試的痕跡)
# ==============================================================================
log_info "═══════ 9. 殘留檔案檢查 ═══════"
echo ""

LEFTOVER_FILES=(
    "/root/Documents/Albert_Cycle_State.ini"
    "/root/Documents/.current_session"
    "$HOME/.config/autostart/auto_test.desktop"
    "$HOME/.config/systemd/user/albert-sit-resume.service"
    "./config/test_queue.run"
    "./config/.inter_test_delay"
)

LEFTOVERS_FOUND=0
for f in "${LEFTOVER_FILES[@]}"; do
    if [[ -f "$f" ]]; then
        log_warn "  ⚠️  發現殘留檔案: $f"
        LEFTOVERS_FOUND=$((LEFTOVERS_FOUND + 1))
    fi
done

if [[ "$LEFTOVERS_FOUND" -gt 0 ]]; then
    log_warn "  ⚠️  發現 $LEFTOVERS_FOUND 個殘留檔案,代表上次測試未正常結束"
    add_hint "執行: sudo bash stop_reboot_test.sh   # 清理殘留"
    TOTAL_WARNINGS=$((TOTAL_WARNINGS + 1))
else
    log_pass "  ✓ 沒有殘留檔案"
fi

echo ""

# ==============================================================================
# 10. 結果摘要
# ==============================================================================
echo -e "${C_INFO}╔════════════════════════════════════════════════════════════════╗${C_RESET}"
echo -e "${C_INFO}║  📊 環境檢查結果                                                ║${C_RESET}"
echo -e "${C_INFO}╚════════════════════════════════════════════════════════════════╝${C_RESET}"
echo ""

if [[ $TOTAL_ERRORS -eq 0 ]] && [[ $TOTAL_WARNINGS -eq 0 ]]; then
    log_pass "═══════════════════════════════════════════════════════════════════"
    log_pass "  ✅ 環境完美!可以立即開始測試"
    log_pass "═══════════════════════════════════════════════════════════════════"
    echo ""
    echo -e "  下一步: ${C_PASS}sudo bash regression_test.sh${C_RESET}"
elif [[ $TOTAL_ERRORS -eq 0 ]]; then
    log_warn "═══════════════════════════════════════════════════════════════════"
    log_warn "  ⚠️  發現 $TOTAL_WARNINGS 個警告 (不影響執行,但建議修復)"
    log_warn "═══════════════════════════════════════════════════════════════════"
else
    log_error "═══════════════════════════════════════════════════════════════════"
    log_error "  ❌ 發現 $TOTAL_ERRORS 個錯誤、$TOTAL_WARNINGS 個警告"
    log_error "  必須修復錯誤才能執行測試"
    log_error "═══════════════════════════════════════════════════════════════════"
fi

# 顯示修復建議
if [[ ${#HINTS[@]} -gt 0 ]]; then
    echo ""
    log_info "💡 修復建議 (按優先順序):"
    echo ""
    # 去重複後顯示
    i=1
    seen=()
    for hint in "${HINTS[@]}"; do
        if [[ ! " ${seen[*]} " =~ " $hint " ]]; then
            echo -e "    ${C_INFO}${i}.${C_RESET} $hint"
            seen+=("$hint")
            i=$((i + 1))
        fi
    done
fi

echo ""

# Exit code
if [[ $TOTAL_ERRORS -gt 0 ]]; then
    exit 1
elif [[ $TOTAL_WARNINGS -gt 0 ]]; then
    exit 2
else
    exit 0
fi
