#!/bin/bash

################################################################################
# Project  : SIT Master Regression Controller
# Version  : 5.3 (Inter-Test Delay + Environment Check + TR-14 Support)
# Author   : Albert Zhou (志偉 周)
# Date     : 2026-05-15
#
# 🆕 NEW IN v5.3:
#   ✅ 不同測試類型之間自動等待 5 分鐘 (INTER_TEST_DELAY 可調整)
#      → 讓上一個測試完整收集 log
#      → 為下一個測試做準備
#   ✅ 啟動前完整環境檢查 (preflight_check)
#      → 缺 package 立即提示工程師
#      → 缺 tool 立即提示工程師 (ipmitool, rtcwake, dmidecode 等)
#      → 自動偵測 TR-14 工具與 serial port
#      → 列出 systemd / autostart 環境狀態
#   ✅ 支援 TR-14 真實 AC 切電 (engine v6.0 配套)
#   ✅ 互動式延遲時間設定 (可在啟動時調整)
#
# v5.2 RHEL 10 FIX:
#   ✅ 支援 systemd service + timer (不依賴桌面環境)
#   ✅ autostart 改為 systemd unit, RHEL 10 原生可靠
#   ✅ 自動偵測環境: 優先 systemd, fallback 到 .desktop
#
################################################################################

set -euo pipefail

# ==============================================================================
# Constants
# ==============================================================================

readonly SCRIPT_VERSION="5.3"
readonly COUNTDOWN_SECONDS=30
readonly ENGINE_SCRIPT="Albert_Ultimate_Cycle_Test.sh"
readonly STATE_FILE="/root/Documents/Albert_Cycle_State.ini"
readonly SESSION_ID_FILE="/root/Documents/.current_session"
readonly BOOTSTRAP_LOG="/root/Documents/bootstrap.log"
readonly WORKDIR_PERSIST="/usr/auto.pwd"
readonly QUEUE_FILE_REL="config/test_queue.run"
readonly AUTOSTART_DIR="${HOME}/.config/autostart"
readonly AUTOSTART_FILE="${AUTOSTART_DIR}/auto_test.desktop"

# 🆕 systemd unit 路徑
readonly SYSTEMD_USER_DIR="${HOME}/.config/systemd/user"
readonly SYSTEMD_SERVICE="${SYSTEMD_USER_DIR}/albert-sit-resume.service"

# ════════════════════════════════════════════════════════════════════════════
# 🆕 v5.3: Inter-Test Delay (測試類型間隔)
# ════════════════════════════════════════════════════════════════════════════
# 不同測試類型之間等待的秒數 (預設 5 分鐘)
# 目的: 讓上一個測試完整收集 log、給下一個測試準備時間
# 可在啟動時透過互動式提示修改
INTER_TEST_DELAY=300                         # 預設 5 分鐘 = 300 秒
readonly INTER_TEST_DELAY_MIN=60             # 最小 1 分鐘
readonly INTER_TEST_DELAY_MAX=1800           # 最大 30 分鐘
readonly INTER_TEST_DELAY_DEFAULT=300        # 預設 5 分鐘

# ════════════════════════════════════════════════════════════════════════════
# 🆕 v5.3: TR-14 Hardware Tool (相對路徑)
# ════════════════════════════════════════════════════════════════════════════
readonly TR14_TOOL_REL="tools/tr-14"         # 相對於工作目錄

# Colors
readonly C_INFO="\e[1;36m"
readonly C_PASS="\e[1;32m"
readonly C_WARN="\e[1;33m"
readonly C_ERROR="\e[1;31m"
readonly C_DEBUG="\e[0;37m"
readonly C_RESET="\e[0m"

# Globals (filled in main)
pwdd=""
RESUME_MODE=0
DEBUG="${DEBUG:-0}"
AUTOSTART_METHOD="auto"  # auto / systemd / desktop

# ==============================================================================
# Logging
# ==============================================================================

bootstrap_log() {
    local msg="$1"
    local ts
    ts="$(date +"%Y-%m-%d %H:%M:%S")"
    mkdir -p "$(dirname "$BOOTSTRAP_LOG")" 2>/dev/null || true
    echo "[$ts] [regression] $msg" >> "$BOOTSTRAP_LOG" 2>/dev/null || true
}

log_info()  { echo -e "${C_INFO}[INFO]${C_RESET} $1";  bootstrap_log "INFO: $1"; }
log_pass()  { echo -e "${C_PASS}[PASS]${C_RESET} $1";  bootstrap_log "PASS: $1"; }
log_warn()  { echo -e "${C_WARN}[WARN]${C_RESET} $1";  bootstrap_log "WARN: $1"; }
log_error() { echo -e "${C_ERROR}[ERROR]${C_RESET} $1"; bootstrap_log "ERROR: $1"; }
log_debug() {
    if [[ "${DEBUG:-0}" == "1" ]]; then
        echo -e "${C_DEBUG}[DEBUG]${C_RESET} $1"
        bootstrap_log "DEBUG: $1"
    fi
}

# ==============================================================================
# Working Directory Resolution
# ==============================================================================

resolve_workdir() {
    if [[ ! -f "$WORKDIR_PERSIST" ]]; then
        pwd > "$WORKDIR_PERSIST"
    fi
    pwdd=$(cat "$WORKDIR_PERSIST")
    if [[ ! -d "$pwdd" ]]; then
        log_error "工作目錄不存在: $pwdd"
        exit 2
    fi
    cd "$pwdd" || { log_error "無法 cd 到 $pwdd"; exit 2; }
    log_debug "工作目錄: $pwdd"
}

# ==============================================================================
# Environment Detection (RHEL 10 support)
# ==============================================================================

detect_init_system() {
    # 🆕 偵測初始化系統
    if command -v systemctl &>/dev/null && [[ -d /run/systemd/system ]]; then
        echo "systemd"
    else
        echo "sysvinit"
    fi
}

detect_desktop_environment() {
    # 🆕 偵測桌面環境
    if [[ -n "${GNOME_SHELL_SESSION:-}" ]] || command -v gnome-shell &>/dev/null; then
        echo "gnome"
    elif [[ -n "${KDE_SESSION:-}" ]] || command -v kwinit &>/dev/null; then
        echo "kde"
    elif [[ -n "${XFCE_DESKTOP_PORTAL:-}" ]] || command -v xfdesktop &>/dev/null; then
        echo "xfce"
    else
        echo "none"
    fi
}

detect_terminal() {
    if   command -v gnome-terminal &>/dev/null; then echo "gnome-terminal"
    elif command -v ptyxis         &>/dev/null; then echo "ptyxis"
    elif command -v xterm          &>/dev/null; then echo "xterm"
    else echo "bash"
    fi
}

# ==============================================================================
# Autostart Management (v5.2 - systemd + .desktop hybrid)
# ==============================================================================

create_systemd_service() {
    # 🆕 建立 systemd user service
    mkdir -p "$SYSTEMD_USER_DIR"

    cat > "$SYSTEMD_SERVICE" << 'EOF'
[Unit]
Description=Albert SIT Auto Test Resume
After=network.target
StartLimitBurst=0

[Service]
Type=simple
ExecStart=/bin/bash -c "sleep 10 && cd '%WORKDIR%' && bash '%WORKDIR%/regression_test.sh' --resume"
Restart=no
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
EOF

    # 替換佔位符
    sed -i "s|%WORKDIR%|$pwdd|g" "$SYSTEMD_SERVICE"
    chmod 644 "$SYSTEMD_SERVICE"

    log_pass "✓ systemd service 已建立: $SYSTEMD_SERVICE"
}

create_desktop_entry() {
    # 保留舊式 .desktop 作為 fallback
    local term_cmd
    term_cmd=$(detect_terminal)

    mkdir -p "$AUTOSTART_DIR"

    cat > "$pwdd/auto_test.desktop" << EOF
[Desktop Entry]
Type=Application
Name=Albert SIT Auto Test (Regression Resume)
Exec=$term_cmd -- bash -c "sleep 3 && cd '$pwdd' && bash '$pwdd/regression_test.sh' --resume"
X-GNOME-Autostart-enabled=true
X-GNOME-Autostart-Delay=5
Terminal=false
Icon=system-run
Categories=System;
StartupNotify=false
EOF

    cp -f "$pwdd/auto_test.desktop" "$AUTOSTART_FILE"
    chmod 644 "$AUTOSTART_FILE"

    if command -v gio &>/dev/null; then
        gio set "$AUTOSTART_FILE" "metadata::trusted" true 2>/dev/null || true
        gio trust "$AUTOSTART_FILE" 2>/dev/null || true
    fi

    log_pass "✓ .desktop autostart 已建立: $AUTOSTART_FILE"
}

setup_autostart() {
    # 🆕 混合策略：systemd 優先，.desktop fallback
    local init_sys
    init_sys=$(detect_init_system)

    log_info "偵測初始化系統: $init_sys"

    if [[ "$init_sys" == "systemd" ]]; then
        log_info "建立 systemd service (RHEL 10 適配)..."
        create_systemd_service

        # 啟用 systemd service
        if systemctl --user daemon-reload 2>/dev/null; then
            systemctl --user enable albert-sit-resume.service 2>/dev/null || true
            log_pass "✓ systemd service 已啟用"
            AUTOSTART_METHOD="systemd"
        else
            log_warn "⚠️  systemd --user daemon-reload 失敗,退而建立 .desktop"
            create_desktop_entry
            AUTOSTART_METHOD="desktop"
        fi
    else
        log_info "未偵測到 systemd,使用傳統 .desktop"
        create_desktop_entry
        AUTOSTART_METHOD="desktop"
    fi

    log_pass "✓ Autostart 已建立 (方法: $AUTOSTART_METHOD)"
}

ensure_autostart_present() {
    # 🆕 重啟後確保 autostart 還在
    local init_sys
    init_sys=$(detect_init_system)

    if [[ "$init_sys" == "systemd" ]]; then
        # 檢查 systemd service 是否啟用
        if systemctl --user is-enabled albert-sit-resume.service &>/dev/null; then
            log_debug "systemd service 仍啟用"
        else
            log_warn "systemd service 未啟用,重新啟用中..."
            systemctl --user daemon-reload 2>/dev/null || true
            systemctl --user enable albert-sit-resume.service 2>/dev/null || true
        fi
    else
        # 檢查 .desktop 是否存在
        if [[ ! -f "$AUTOSTART_FILE" ]]; then
            log_warn "Autostart 檔案不存在,重建中..."
            create_desktop_entry
        fi
    fi
}

remove_autostart() {
    # 🆕 清理所有 autostart (systemd + .desktop)
    local init_sys
    init_sys=$(detect_init_system)

    if [[ "$init_sys" == "systemd" ]] && [[ -f "$SYSTEMD_SERVICE" ]]; then
        log_info "移除 systemd service..."
        systemctl --user disable albert-sit-resume.service 2>/dev/null || true
        systemctl --user daemon-reload 2>/dev/null || true
        rm -f "$SYSTEMD_SERVICE"
        log_debug "systemd service 已移除"
    fi

    rm -f "$AUTOSTART_FILE" 2>/dev/null || true
    rm -f "$pwdd/auto_test.desktop" 2>/dev/null || true
    log_debug "Autostart 已移除"
}

# ==============================================================================
# 🆕 v5.3: Preflight Environment Check (環境完整性檢查)
# ==============================================================================

preflight_check() {
    log_info "════════════════════════════════════════════════════════════════"
    log_info "🔍 環境檢查 (Preflight Check)"
    log_info "════════════════════════════════════════════════════════════════"

    local errors=0
    local warnings=0
    local hints=()

    # ─────── 1. 核心 Linux 工具 (必要) ───────
    log_info "[1/5] 檢查核心 Linux 工具..."
    local required_cmds=(bash awk sed grep cut tr head sleep mkdir rm cp chmod sync)
    local missing_required=()
    for cmd in "${required_cmds[@]}"; do
        if ! command -v "$cmd" &>/dev/null; then
            missing_required+=("$cmd")
        fi
    done

    if [[ ${#missing_required[@]} -gt 0 ]]; then
        log_error "❌ 核心工具缺失: ${missing_required[*]}"
        hints+=("dnf install -y coreutils bash gawk grep sed")
        errors=$((errors + 1))
    else
        log_pass "  ✓ 核心 Linux 工具齊全"
    fi

    # ─────── 2. systemd 環境 (RHEL 10 必要) ───────
    log_info "[2/5] 檢查 systemd 環境..."
    if command -v systemctl &>/dev/null && [[ -d /run/systemd/system ]]; then
        log_pass "  ✓ systemd 可用 (autostart 將使用 systemd)"
    else
        log_warn "  ⚠️  systemd 不可用,將降級使用 .desktop autostart"
        warnings=$((warnings + 1))
        hints+=("RHEL 10 強烈建議使用 systemd")
    fi

    # ─────── 3. 測試工具檢查 (依據選擇的測試類型) ───────
    log_info "[3/5] 檢查測試工具..."
    
    # 檢查 ipmitool (AC/DC 需要)
    if [[ -f "$pwdd/config/ac_test" ]] || [[ -f "$pwdd/config/dc_test" ]]; then
        if command -v ipmitool &>/dev/null; then
            local ipmi_ver
            ipmi_ver=$(ipmitool -V 2>/dev/null | head -1 || echo "未知版本")
            log_pass "  ✓ ipmitool 已安裝: $ipmi_ver"
        else
            log_error "  ❌ ipmitool 未安裝 (AC/DC 測試必要)"
            hints+=("dnf install -y ipmitool")
            errors=$((errors + 1))
        fi

        # 檢查 ipmi.conf
        if [[ -f "$pwdd/config/ipmi.conf" ]]; then
            log_pass "  ✓ config/ipmi.conf 已配置"
        else
            log_error "  ❌ config/ipmi.conf 不存在 (AC/DC 必要)"
            hints+=("執行 sudo bash ver.sh 重新配置 BMC")
            errors=$((errors + 1))
        fi
    fi

    # 檢查 rtcwake (DC/AC fallback 需要)
    if command -v rtcwake &>/dev/null; then
        log_pass "  ✓ rtcwake 已安裝"
        if [[ -e /sys/class/rtc/rtc0/wakealarm ]]; then
            log_pass "  ✓ RTC 喚醒裝置可用 (/sys/class/rtc/rtc0/wakealarm)"
        else
            log_warn "  ⚠️  RTC 喚醒裝置不可用 (BIOS 需啟用 RTC Wake)"
            warnings=$((warnings + 1))
        fi
    else
        log_warn "  ⚠️  rtcwake 未安裝 (建議: 自動喚醒備援)"
        hints+=("dnf install -y util-linux")
        warnings=$((warnings + 1))
    fi

    # 檢查 dmidecode, pciutils (硬體採集需要)
    for cmd_tool in dmidecode lspci; do
        if command -v "$cmd_tool" &>/dev/null; then
            log_pass "  ✓ $cmd_tool 已安裝"
        else
            log_warn "  ⚠️  $cmd_tool 未安裝 (硬體採集會缺資料)"
            case "$cmd_tool" in
                dmidecode) hints+=("dnf install -y dmidecode") ;;
                lspci)     hints+=("dnf install -y pciutils") ;;
            esac
            warnings=$((warnings + 1))
        fi
    done

    # ─────── 4. TR-14 工具檢查 (AC 真實切電必要) ───────
    log_info "[4/5] 檢查 TR-14 切電工具..."
    if [[ -f "$pwdd/config/ac_test" ]]; then
        local tr14_path="$pwdd/$TR14_TOOL_REL"
        if [[ -x "$tr14_path" ]]; then
            log_pass "  ✓ TR-14 工具存在: $TR14_TOOL_REL"
            log_pass "  ✓ 可執行權限正確"
            
            # 嘗試偵測 serial port
            local found_port=""
            for port in /dev/ttyS0 /dev/ttyUSB0; do
                if [[ -c "$port" ]]; then
                    if [[ -r "$port" ]] && [[ -w "$port" ]]; then
                        found_port="$port"
                        log_pass "  ✓ Serial port 可用: $port"
                        break
                    else
                        log_warn "  ⚠️  $port 存在但無讀寫權限"
                    fi
                fi
            done
            
            if [[ -z "$found_port" ]]; then
                log_warn "  ⚠️  找不到可用的 serial port (/dev/ttyS0, /dev/ttyUSB0)"
                log_warn "      AC 測試將降級使用 IPMI poweroff (非真實 AC)"
                hints+=("檢查 TR-14 連線並重新插拔 USB/Serial 線")
                warnings=$((warnings + 1))
            fi
        else
            log_warn "  ⚠️  TR-14 工具不存在或無執行權限: $TR14_TOOL_REL"
            log_warn "      AC 測試將降級使用 IPMI poweroff (非真實 AC)"
            hints+=("將 tr-14 放到 $pwdd/tools/ 並執行 chmod 755 tools/tr-14")
            warnings=$((warnings + 1))
        fi
    else
        log_info "  ⊘ AC 測試未啟用,略過 TR-14 檢查"
    fi

    # ─────── 5. 工作環境檢查 ───────
    log_info "[5/5] 檢查工作環境..."
    
    # 磁碟空間
    local avail_kb
    avail_kb=$(df /root 2>/dev/null | tail -1 | awk '{print $4}')
    if [[ -n "$avail_kb" ]] && [[ "$avail_kb" -gt 1048576 ]]; then
        log_pass "  ✓ /root 磁碟空間充足 ($((avail_kb / 1024)) MB)"
    else
        log_warn "  ⚠️  /root 磁碟空間 < 1GB (可能不夠存放 log)"
        warnings=$((warnings + 1))
    fi

    # 結果目錄
    if [[ -d /root/Documents ]] || mkdir -p /root/Documents 2>/dev/null; then
        log_pass "  ✓ /root/Documents 可寫"
    else
        log_error "  ❌ 無法建立 /root/Documents"
        errors=$((errors + 1))
    fi

    # zip 工具 (打包結果)
    if command -v zip &>/dev/null; then
        log_pass "  ✓ zip 已安裝 (結果打包)"
    else
        log_warn "  ⚠️  zip 未安裝 (測試完成後無法自動打包)"
        hints+=("dnf install -y zip")
        warnings=$((warnings + 1))
    fi

    # ─────── 總結 ───────
    echo ""
    log_info "════════════════════════════════════════════════════════════════"
    log_info "📊 環境檢查結果"
    log_info "════════════════════════════════════════════════════════════════"
    
    if [[ $errors -eq 0 ]] && [[ $warnings -eq 0 ]]; then
        log_pass "✅ 環境完美!可以開始測試"
    elif [[ $errors -eq 0 ]]; then
        log_warn "⚠️  發現 $warnings 個警告 (不影響執行,但建議修復)"
    else
        log_error "❌ 發現 $errors 個錯誤、$warnings 個警告"
        log_error "   無法繼續執行,請依照下方提示修復"
    fi

    # 提示修復方法
    if [[ ${#hints[@]} -gt 0 ]]; then
        echo ""
        log_info "💡 修復建議:"
        local i=1
        for hint in "${hints[@]}"; do
            echo -e "    ${C_INFO}${i}.${C_RESET} $hint"
            i=$((i + 1))
        done
    fi

    echo ""

    # 致命錯誤時中止
    if [[ $errors -gt 0 ]]; then
        log_error "請先修復上述錯誤再執行測試"
        exit 1
    fi

    # 警告時提示使用者確認
    if [[ $warnings -gt 0 ]]; then
        read -r -p "$(echo -e ${C_WARN}'⚠️  仍有警告,是否繼續? (y/N): '${C_RESET})" ans
        if [[ ! "$ans" =~ ^[Yy]$ ]]; then
            log_info "已取消,請修復警告後重試"
            exit 0
        fi
    fi
}

# ==============================================================================
# 🆕 v5.3: Inter-Test Delay (測試類型間隔等待)
# ==============================================================================

wait_between_tests() {
    local prev_type="$1"
    local next_type="$2"
    local delay="${3:-$INTER_TEST_DELAY}"

    # 同類型不等待 (例如 DC 第 1 圈 → DC 第 2 圈, 不算「不同類型」)
    if [[ "$prev_type" == "$next_type" ]]; then
        return 0
    fi

    log_info "════════════════════════════════════════════════════════════════"
    log_info "⏸️  測試類型切換: $prev_type → $next_type"
    log_info "等待 ${delay} 秒 (${delay} / 60 = $((delay / 60)) 分鐘)"
    log_info "  目的:"
    log_info "    • 讓 $prev_type 完整收集 log"
    log_info "    • 為 $next_type 做準備"
    log_info "    • 系統穩定化"
    log_info "════════════════════════════════════════════════════════════════"

    # 倒數顯示
    local remaining=$delay
    while [[ $remaining -gt 0 ]]; do
        local mins=$((remaining / 60))
        local secs=$((remaining % 60))
        echo -ne "\r${C_INFO}[INFO]${C_RESET} ⏳ 剩餘: ${mins}m ${secs}s   (按 Ctrl+C 中止)   "
        sleep 1
        remaining=$((remaining - 1))
    done
    echo ""

    log_pass "✓ 間隔等待完成,準備執行 $next_type"
}

ask_inter_test_delay() {
    # 互動式詢問是否調整間隔時間
    echo ""
    echo -e "${C_INFO}════════════════════════════════════════════════════════════════${C_RESET}"
    echo -e "${C_INFO}📋 測試類型間隔設定${C_RESET}"
    echo -e "${C_INFO}════════════════════════════════════════════════════════════════${C_RESET}"
    echo -e "  不同測試類型 (REBOOT / AC / DC / SHUTDOWN) 之間的等待時間"
    echo -e "  目前設定: ${C_WARN}${INTER_TEST_DELAY} 秒 ($((INTER_TEST_DELAY / 60)) 分鐘)${C_RESET}"
    echo -e "  範圍: ${INTER_TEST_DELAY_MIN}-${INTER_TEST_DELAY_MAX} 秒"
    echo ""
    
    read -r -p "👉 是否要修改間隔時間? (y/N): " modify
    
    if [[ "$modify" =~ ^[Yy]$ ]]; then
        read -r -p "👉 請輸入新的間隔秒數 (預設 ${INTER_TEST_DELAY_DEFAULT}): " new_delay
        new_delay="${new_delay:-$INTER_TEST_DELAY_DEFAULT}"
        
        if [[ "$new_delay" =~ ^[0-9]+$ ]] && \
           [[ "$new_delay" -ge "$INTER_TEST_DELAY_MIN" ]] && \
           [[ "$new_delay" -le "$INTER_TEST_DELAY_MAX" ]]; then
            INTER_TEST_DELAY=$new_delay
            log_pass "✓ 間隔已設為 ${INTER_TEST_DELAY} 秒 ($((INTER_TEST_DELAY / 60)) 分鐘)"
        else
            log_warn "⚠️  無效值,使用預設 ${INTER_TEST_DELAY_DEFAULT} 秒"
            INTER_TEST_DELAY=$INTER_TEST_DELAY_DEFAULT
        fi
    else
        log_info "使用預設間隔: ${INTER_TEST_DELAY} 秒 ($((INTER_TEST_DELAY / 60)) 分鐘)"
    fi

    # 把設定寫入持久化檔案,resume 時可讀取
    echo "$INTER_TEST_DELAY" > "$pwdd/config/.inter_test_delay" 2>/dev/null || true
}

load_inter_test_delay() {
    # 從持久化檔案讀取 (resume mode 用)
    if [[ -f "$pwdd/config/.inter_test_delay" ]]; then
        local saved
        saved=$(cat "$pwdd/config/.inter_test_delay" 2>/dev/null | tr -d '[:space:]')
        if [[ "$saved" =~ ^[0-9]+$ ]]; then
            INTER_TEST_DELAY=$saved
            log_debug "從檔案載入間隔: ${INTER_TEST_DELAY} 秒"
        fi
    fi
}

# ==============================================================================
# Ghost State Cleanup
# ==============================================================================

cleanup_ghost_states() {
    log_warn "清理舊狀態檔(防止幽靈圈數)..."

    local files=(
        "$pwdd/Albert_Cycle_State.ini"
        "$STATE_FILE"
        "$SESSION_ID_FILE"
        "$AUTOSTART_FILE"
        "/etc/auto_test.desktop"
        "$pwdd/$QUEUE_FILE_REL"
    )

    local f
    for f in "${files[@]}"; do
        if [[ -f "$f" ]]; then
            log_debug "刪除: $f"
            rm -f "$f" 2>/dev/null || log_warn "無法刪除: $f"
        fi
    done

    rm -f /root/*.log 2>/dev/null || true
    mkdir -p "$pwdd/result" /root/Documents
    log_pass "✓ 舊狀態檔清理完成"
}

# ==============================================================================
# Queue Management (unchanged from v5.1)
# ==============================================================================

queue_path() {
    echo "$pwdd/$QUEUE_FILE_REL"
}

queue_clear() {
    : > "$(queue_path)"
}

queue_append() {
    local type=$1
    local cycles=$2
    echo "$type $cycles" >> "$(queue_path)"
}

queue_peek() {
    head -n1 "$(queue_path)" 2>/dev/null || echo ""
}

queue_pop() {
    local q
    q="$(queue_path)"
    if [[ -f "$q" ]]; then
        sed -i '1d' "$q" 2>/dev/null || true
    fi
}

queue_size() {
    if [[ ! -f "$(queue_path)" ]]; then
        echo 0
        return
    fi

    local count
    count=$(grep -cv '^[[:space:]]*$' "$(queue_path)" 2>/dev/null) || count=0
    count=$(echo -n "$count" | tr -d '[:space:]')
    
    if [[ "$count" =~ ^[0-9]+$ ]]; then
        echo "$count"
    else
        echo 0
    fi
}

# ==============================================================================
# 其他函式保持不變 (build_queue_from_config, call_engine 等)
# ==============================================================================

build_queue_from_config() {
    log_info "從 config/ 中建立測試佇列..."

    queue_clear

    local entries=(
        "REBOOT:reboot_test:reboottime"
        "AC:ac_test:ac_time"
        "DC:dc_test:dc_time"
        "SHUTDOWN:shutdown_test:shutdown_time"
    )

    local added=0
    local entry type flag time_file cycles
    for entry in "${entries[@]}"; do
        IFS=':' read -r type flag time_file <<< "$entry"

        if [[ ! -f "$pwdd/config/$flag" ]]; then
            log_debug "$type 未啟用,跳過"
            continue
        fi

        cycles=$(cat "$pwdd/config/$time_file" 2>/dev/null | tr -d '[:space:]' || echo "10")
        if ! [[ "$cycles" =~ ^[0-9]+$ ]] || [[ "$cycles" -lt 1 ]]; then
            log_warn "$type 循環次數無效 ($cycles),改用 10"
            cycles=10
        fi

        queue_append "$type" "$cycles"
        added=$((added + 1))
        log_pass "  ✓ 加入佇列: $type × $cycles"
    done

    if [[ $added -eq 0 ]]; then
        log_error "❌ 沒有任何測試類型被啟用,請執行 sudo bash ver.sh 重新配置"
        exit 1
    fi

    log_pass "✓ 佇列建立完成,共 $added 項"
}

call_engine() {
    local type=$1
    local cycles=$2

    if [[ -z "$type" ]] || [[ -z "$cycles" ]]; then
        log_error "════════════════════════════════════════════════════════════════"
        log_error "❌ FATAL: call_engine 收到空參數"
        log_error "   TYPE='$type' CYCLES='$cycles'"
        log_error "════════════════════════════════════════════════════════════════"
        remove_autostart
        rm -f "$STATE_FILE" "$SESSION_ID_FILE" 2>/dev/null || true
        exit 2
    fi

    case "$type" in
        REBOOT|AC|DC|SHUTDOWN) ;;
        *)
            log_error "❌ FATAL: 無效的 TEST TYPE: '$type'"
            remove_autostart
            exit 2
            ;;
    esac

    if ! [[ "$cycles" =~ ^[0-9]+$ ]] || [[ "$cycles" -lt 1 ]]; then
        log_error "❌ FATAL: 無效的 CYCLES: '$cycles'"
        remove_autostart
        exit 2
    fi

    log_info "================================================================"
    log_info "呼叫 engine: TYPE=$type CYCLES=$cycles"
    log_info "================================================================"

    if [[ ! -f "$pwdd/$ENGINE_SCRIPT" ]]; then
        log_error "❌ engine 腳本不存在: $pwdd/$ENGINE_SCRIPT"
        exit 4
    fi

    sync
    sleep 1

    set +e
    bash "$pwdd/$ENGINE_SCRIPT" -t "$type" -c "$cycles"
    local rc=$?
    set -e

    log_info "engine 返回 rc=$rc"
    return $rc
}

check_ipmi_config_for_queue() {
    local q
    q="$(queue_path)"
    if [[ ! -f "$q" ]]; then return; fi

    if grep -qE '^(AC|DC) ' "$q"; then
        if [[ ! -f "$pwdd/config/ipmi.conf" ]]; then
            log_error "═════════════════════════════════════════════════════════"
            log_error "❌ 佇列含 AC 或 DC 測試,但找不到 $pwdd/config/ipmi.conf"
            log_error "════════════════════════════════════════════════════════="
            log_warn "範例 (請建立 $pwdd/config/ipmi.conf):"
            cat << 'EOF'
  IPMI_HOST=192.168.10.35
  IPMI_USER=root
  IPMI_PASS=P@ssw0rd
  IPMI_INTERFACE=lanplus
EOF
            echo ""
            read -r -p "是否仍要繼續 (y/N)? " ans
            if [[ ! "$ans" =~ ^[Yy]$ ]]; then
                log_info "已中止"
                exit 1
            fi
        else
            chmod 600 "$pwdd/config/ipmi.conf" 2>/dev/null || true
            log_pass "✓ 找到 ipmi.conf"
        fi
    fi
}

package_results() {
    log_info "================================================================"
    log_info "                    打包測試結果"
    log_info "================================================================"

    if [[ ! -d "$pwdd/result" ]] && [[ ! -d "/root/Documents" ]]; then
        log_warn "無可打包的結果檔案"
        return
    fi

    if ! command -v zip &>/dev/null; then
        log_warn "zip 未安裝,跳過打包"
        return
    fi

    local timestamp
    timestamp=$(date +"%Y%m%d_%H%M%S")
    local zip_file="$pwdd/result/auto_regression_test_result_${timestamp}.zip"

    mkdir -p "$pwdd/result"

    if zip -r "$zip_file" "$pwdd/result" /root/Documents >/dev/null 2>&1; then
        log_pass "✓ 結果已打包: $zip_file"
    else
        log_warn "打包失敗"
    fi
}

# ==============================================================================
# Mode: Fresh Start
# ==============================================================================

show_warning_and_countdown() {
    clear
    echo -e "${C_ERROR}╔════════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_ERROR}║   [WARNING]  AUTOMATED CYCLE TEST              ║${C_RESET}"
    echo -e "${C_ERROR}║   Regression Controller v${SCRIPT_VERSION}                  ║${C_RESET}"
    echo -e "${C_ERROR}╚════════════════════════════════════════════════╝${C_RESET}"
    echo ""
    echo -e "${C_WARN}此腳本將自動執行多次重啟/關機/電源循環操作${C_RESET}"
    echo -e "${C_WARN}❌ 所有未保存的工作將遺失!${C_RESET}"
    echo ""
    echo -e "${C_WARN}如果您需要停止測試,請在倒數結束前按 [Ctrl+C]${C_RESET}"
    echo ""

    local i
    for i in $(seq $COUNTDOWN_SECONDS -1 1); do
        echo -ne "\r⚠️  測試將在 ${C_ERROR}$i${C_RESET} 秒後開始,按 Ctrl+C 中斷...   "
        sleep 1
    done
    echo -e "\n\n${C_INFO}🚀 倒數結束,開始建立佇列...${C_RESET}\n"
}

run_fresh_start() {
    show_warning_and_countdown

    resolve_workdir

    if [[ ! -f "$pwdd/config/regression_test" ]]; then
        log_error "❌ 配置檔案不存在: $pwdd/config/regression_test"
        log_warn "請先執行: sudo bash ver.sh"
        exit 1
    fi
    log_pass "✓ 配置檔案驗證通過"

    # 🆕 v5.3: 環境完整性檢查
    preflight_check

    cleanup_ghost_states
    build_queue_from_config

    echo ""
    log_info "佇列內容 (執行順序):"
    cat "$(queue_path)" | nl -ba | sed 's/^/    /'
    echo ""

    check_ipmi_config_for_queue

    # 🆕 v5.3: 多類型測試時詢問間隔時間
    local queue_size_val
    queue_size_val=$(queue_size)
    if [[ "$queue_size_val" -gt 1 ]]; then
        echo ""
        log_info "偵測到多個測試類型 (共 $queue_size_val 項)"
        ask_inter_test_delay
    fi

    setup_autostart  # 使用混合 autostart (systemd/desktop)

    local first
    first="$(queue_peek)"
    local first_type first_cycles
    first_type=$(echo "$first" | awk '{print $1}')
    first_cycles=$(echo "$first" | awk '{print $2}')

    log_info "════════════════════════════════════════════════════════════════"
    log_info "開始執行第一個測試類型: $first_type × $first_cycles cycles"
    log_info "(後續類型將透過 systemd/autostart 自動接力)"
    if [[ "$queue_size_val" -gt 1 ]]; then
        log_info "(類型切換間隔: ${INTER_TEST_DELAY} 秒 = $((INTER_TEST_DELAY / 60)) 分鐘)"
    fi
    log_info "════════════════════════════════════════════════════════════════"

    call_engine "$first_type" "$first_cycles"

    log_warn "engine 異常返回"
    exit 5
}

# ==============================================================================
# Mode: Resume
# ==============================================================================

run_resume_mode() {
    log_info "════════════════════════════════════════════════════════════════"
    log_info "Resume Mode — 開機後 autostart 觸發"
    log_info "════════════════════════════════════════════════════════════════"

    resolve_workdir

    # 🆕 v5.3: 載入持久化的間隔設定
    load_inter_test_delay

    ensure_autostart_present

    if [[ ! -f "$(queue_path)" ]]; then
        log_error "❌ 佇列檔不存在"
        remove_autostart
        exit 1
    fi

    if [[ -f "$STATE_FILE" ]]; then
        local cur_type cur_max
        cur_type=$(grep "^TEST_TYPE=" "$STATE_FILE" 2>/dev/null | cut -d= -f2 | head -n1)
        cur_max=$(grep "^MAX_CYCLES=" "$STATE_FILE" 2>/dev/null | cut -d= -f2 | head -n1)
        cur_type="${cur_type:-REBOOT}"
        cur_max="${cur_max:-10}"

        log_info "STATE_FILE 存在 → engine 中途狀態 (TYPE=$cur_type, MAX=$cur_max)"
        call_engine "$cur_type" "$cur_max"
        log_info "engine 已返回,STATE_FILE 應已被 engine 刪除"
    else
        log_info "STATE_FILE 不存在 → 上一個 type 已 finalize,進入佇列推進"
    fi

    # 🆕 v5.3: 記錄剛完成的類型 (用於切換等待)
    local just_finished_type=""
    local just_finished
    just_finished="$(queue_peek)"
    if [[ -n "$just_finished" ]]; then
        just_finished_type=$(echo "$just_finished" | awk '{print $1}')
        log_pass "✓ 已完成佇列項目: $just_finished"
        queue_pop
    fi

    local remaining
    remaining=$(queue_size)
    remaining=$(echo -n "$remaining" | tr -d '[:space:]')
    if ! [[ "$remaining" =~ ^[0-9]+$ ]]; then
        log_warn "queue_size 回傳異常值,強制視為 0"
        remaining=0
    fi
    log_info "佇列剩餘: ${remaining} 項"

    if [[ "$remaining" -eq 0 ]]; then
        log_pass "════════════════════════════════════════════════════════════════"
        log_pass "🎉 所有測試類型已完成!"
        log_pass "════════════════════════════════════════════════════════════════"
        package_results
        remove_autostart
        rm -f "$STATE_FILE" "$SESSION_ID_FILE" 2>/dev/null || true
        rm -f "$(queue_path)" 2>/dev/null || true
        rm -f "$pwdd/config/.inter_test_delay" 2>/dev/null || true
        if command -v rtcwake &>/dev/null; then
            rtcwake -m disable 2>/dev/null || true
        fi
        echo ""
        log_info "結果位置:"
        echo -e "  • Compare_Log:  /root/Documents/Compare_Log_*/"
        echo -e "  • OS_Event_Log: /root/Documents/OS_Event_Log_*/"
        echo ""
        exit 0
    fi

    if [[ "$remaining" -gt 0 ]]; then
        local next next_type next_cycles
        next="$(queue_peek)"

        if [[ -z "$next" ]]; then
            log_error "❌ 邏輯錯誤: queue_size=$remaining,但 queue_peek 為空!"
            remove_autostart
            exit 1
        fi

        next_type=$(echo "$next" | awk '{print $1}')
        next_cycles=$(echo "$next" | awk '{print $2}')

        if [[ -z "$next_type" ]] || [[ -z "$next_cycles" ]]; then
            log_error "❌ 佇列項目格式錯誤: '$next'"
            remove_autostart
            exit 1
        fi

        log_info "════════════════════════════════════════════════════════════════"
        log_info "下一個測試類型: $next_type × $next_cycles cycles"
        log_info "════════════════════════════════════════════════════════════════"

        # 🆕 v5.3: 不同測試類型間等待 (給上一個類型時間收尾)
        if [[ -n "$just_finished_type" ]] && [[ "$just_finished_type" != "$next_type" ]]; then
            wait_between_tests "$just_finished_type" "$next_type" "$INTER_TEST_DELAY"
        fi

        ensure_autostart_present
        call_engine "$next_type" "$next_cycles"

        log_warn "engine 異常返回"
        exit 5
    fi
}

# ==============================================================================
# Mode: Abort
# ==============================================================================

run_abort_mode() {
    log_warn "════════════════════════════════════════════════════════════════"
    log_warn "ABORT MODE — 中止測試,清理所有狀態"
    log_warn "════════════════════════════════════════════════════════════════"

    resolve_workdir

    log_info "移除 autostart..."
    remove_autostart

    log_info "移除狀態檔..."
    rm -f "$STATE_FILE" "$SESSION_ID_FILE" 2>/dev/null || true

    log_info "移除佇列..."
    rm -f "$(queue_path)" 2>/dev/null || true

    if command -v rtcwake &>/dev/null; then
        log_info "取消 RTC 鬧鐘..."
        rtcwake -m disable 2>/dev/null || true
    fi

    log_pass "✓ 已中止"
}

# ==============================================================================
# Mode: Status
# ==============================================================================

run_status_mode() {
    resolve_workdir

    echo ""
    echo -e "${C_INFO}═══════════════ Albert SIT Status (v$SCRIPT_VERSION) ═══════════════${C_RESET}"
    echo ""
    echo -e "工作目錄        : $pwdd"
    echo -e "Engine 腳本     : $pwdd/$ENGINE_SCRIPT"
    echo -e "Autostart 方法  : $AUTOSTART_METHOD (自動偵測)"
    echo -e "systemd service: $SYSTEMD_SERVICE"
    echo -e ".desktop file  : $AUTOSTART_FILE"
    echo ""

    if [[ -f "$STATE_FILE" ]]; then
        echo -e "${C_INFO}── Engine 狀態 ──${C_RESET}"
        cat "$STATE_FILE" | sed 's/^/    /'
        echo ""
    fi

    if [[ -f "$(queue_path)" ]]; then
        echo -e "${C_INFO}── 佇列剩餘 ──${C_RESET}"
        if [[ -s "$(queue_path)" ]]; then
            cat "$(queue_path)" | nl -ba | sed 's/^/    /'
        else
            echo "    (空)"
        fi
        echo ""
    fi
}

# ==============================================================================
# Help
# ==============================================================================

usage() {
    cat << EOF
SIT Master Regression Controller v${SCRIPT_VERSION}
(RHEL 10 systemd Support)

Usage:
  sudo bash regression_test.sh             # 全新啟動 (warn + countdown)
  sudo bash regression_test.sh --resume    # 由 autostart 自動觸發
  sudo bash regression_test.sh --abort     # 中止測試
  sudo bash regression_test.sh --status    # 顯示狀態
  sudo bash regression_test.sh --help      # 此說明

Workflow:
  1. sudo bash ver.sh                # 配置測試項目
  2. sudo bash regression_test.sh    # 開始測試
     (後續重啟自動繼續)
EOF
}

# ==============================================================================
# Main
# ==============================================================================

main() {
    local mode="fresh"

    case "${1:-}" in
        --resume) mode="resume" ;;
        --abort)  mode="abort"  ;;
        --status) mode="status" ;;
        --help|-h) usage; exit 0 ;;
        "")       mode="fresh"  ;;
        *)        log_error "未知參數: $1"; usage; exit 1 ;;
    esac

    bootstrap_log "===== regression v${SCRIPT_VERSION} 啟動 (mode=$mode) ====="

    case "$mode" in
        fresh)  run_fresh_start ;;
        resume) run_resume_mode ;;
        abort)  run_abort_mode  ;;
        status) run_status_mode ;;
    esac
}

main "$@"
