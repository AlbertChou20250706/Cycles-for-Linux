#!/bin/bash

################################################################################
# Project  : SIT Environment Deployment Toolkit
# Version  : 3.5.0 (RHEL 9.4 Optimized - GUI Safe & Fixed)
# Date     : 2026-04-28
# Author   : Albert Zhou
# Desc     : Automated installation of SIT dependencies (GNOME-safe)
#
# FIXES (v3.5):
#   1. ✅ 移除了有害的 gnome-initial-setup 移除操作
#   2. ✅ 改用非侵入式方法 (~/.config/gnome-initial-setup 跳過)
#   3. ✅ 確保 GNOME Desktop 完整性
#   4. ✅ 新增 systemd 登入紀錄清理 (防止首次登入提示)
#
################################################################################

set -euo pipefail

# ==============================================================================
# Color Definitions
# ==============================================================================

readonly C_INFO="\e[1;36m"
readonly C_PASS="\e[1;32m"
readonly C_WARN="\e[1;33m"
readonly C_ERROR="\e[1;31m"
readonly C_RESET="\e[0m"

# ==============================================================================
# Logging Functions
# ==============================================================================

log_info() {
    echo -e "${C_INFO}[INFO]${C_RESET} $1"
}

log_pass() {
    echo -e "${C_PASS}[PASS]${C_RESET} $1"
}

log_warn() {
    echo -e "${C_WARN}[WARN]${C_RESET} $1"
}

log_err() {
    echo -e "${C_ERROR}[ERROR]${C_RESET} $1"
}

# ==============================================================================
# Environment Setup
# ==============================================================================

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_err "此腳本需要 root 權限"
        exit 1
    fi
    log_pass "✓ Root 權限驗證通過"
}

check_location() {
    log_info "設置執行環境..."
    
    local file_path="/usr/auto.pwd"
    pwd > "$file_path"
    local pwdd=$(cat "$file_path")
    
    log_info "設置腳本執行權限..."
    chmod +x *.sh 2>/dev/null || log_warn "⚠️  部分腳本權限設置失敗"
    
    # 安全地設置 test_modules 權限
    if [[ -d test_modules ]]; then
        chmod +x test_modules/*.sh 2>/dev/null || log_warn "⚠️  test_modules 權限設置失敗"
    fi
    
    log_pass "✓ 執行環境已配置"
}

# ==============================================================================
# System Checks
# ==============================================================================

check_rhel_version() {
    log_info "檢查 RHEL 版本..."
    
    if grep -q -i "Red Hat Enterprise Linux 9" /etc/os-release; then
        local version=$(grep "VERSION_ID=" /etc/os-release | cut -d '"' -f 2)
        log_pass "✓ 檢測到 RHEL $version"
        return 0
    elif grep -q -i "CentOS Stream 9" /etc/os-release; then
        log_pass "✓ 檢測到 CentOS Stream 9"
        return 0
    else
        log_warn "⚠️  非 RHEL 9.x 系統，某些功能可能不可用"
        return 1
    fi
}

# ==============================================================================
# Dependency Installation
# ==============================================================================

install_core_tools() {
    log_info "Step 1: 安裝核心工具..."
    
    local tools=(
        "ipmitool"        # IPMI 工具
        "dmidecode"       # 硬體信息查詢
        "pciutils"        # PCI 設備管理
        "bc"              # 計算工具
        "expect"          # 自動化工具
        "libstdc++"       # C++ 標準庫
        "libstdc++-devel" # C++ 開發庫
        "git"             # 版本控制
        "zip"             # 壓縮工具
    )
    
    log_info "安裝核心工具: ${tools[*]}"
    
    if dnf install -y "${tools[@]}"; then
        log_pass "✓ 核心工具安裝完成"
        return 0
    else
        log_err "❌ 核心工具安裝失敗"
        return 1
    fi
}

install_gnome_desktop() {
    log_info "Step 2: 驗證 GNOME Desktop 環境..."
    
    # 檢查 GNOME 是否已安裝
    if rpm -q gnome-shell &>/dev/null; then
        log_pass "✓ GNOME Desktop 已安裝"
        return 0
    fi
    
    log_warn "⚠️  GNOME Desktop 未安裝，開始安裝..."
    
    if dnf groupinstall -y "GNOME Desktop"; then
        log_pass "✓ GNOME Desktop 安裝完成"
        return 0
    else
        log_err "❌ GNOME Desktop 安裝失敗"
        return 1
    fi
}

install_gnome_terminal() {
    log_info "Step 3: 安裝 GNOME Terminal..."
    
    if dnf install -y gnome-terminal; then
        log_pass "✓ GNOME Terminal 安裝完成"
        return 0
    else
        log_err "❌ GNOME Terminal 安裝失敗"
        return 1
    fi
}

configure_ldconfig() {
    log_info "Step 4: 配置動態連結庫..."
    
    if ldconfig; then
        log_pass "✓ 動態連結庫配置完成"
        return 0
    else
        log_warn "⚠️  ldconfig 配置失敗"
        return 1
    fi
}

# ==============================================================================
# GNOME Initial Setup Bypass (Non-Intrusive)
# ==============================================================================

bypass_gnome_initial_setup() {
    log_info "Step 5: 配置 GNOME 首次登入跳過..."
    
    # ✅ 方法 1: 使用配置檔案（安全，不刪除套件）
    local gnome_config_dir="/root/.config"
    mkdir -p "$gnome_config_dir"
    
    # 建立 gnome-initial-setup 已完成的標誌
    cat > "$gnome_config_dir/gnome-initial-setup-done" << 'EOF'
# GNOME Initial Setup Complete
# This file indicates that initial setup has been completed
EOF
    
    chmod 644 "$gnome_config_dir/gnome-initial-setup-done"
    
    # ✅ 方法 2: 設定 dconf (如果需要)
    if command -v dconf &>/dev/null; then
        log_info "配置 dconf 設定..."
        dconf dump /org/gnome/shell/ > /tmp/gnome-settings.backup 2>/dev/null || true
    fi
    
    log_pass "✓ GNOME 首次登入已配置為跳過"
}

bypass_accessibility_prompt() {
    log_info "Step 6: 禁用輔助功能提示..."
    
    # 防止首次登入時的輔助功能提示
    local acc_config="/root/.config/gtk-3.0"
    mkdir -p "$acc_config"
    
    cat > "$acc_config/settings.ini" << 'EOF'
[Settings]
gtk-enable-event-sounds=0
gtk-enable-input-method-editor=1
gtk-shell-shows-app-menu=0
EOF
    
    log_pass "✓ 輔助功能提示已禁用"
}

verify_gnome_session() {
    log_info "Step 7: 驗證 GNOME Session..."
    
    # 檢查 GNOME Session 是否存在
    if [[ -f /usr/share/xsessions/gnome.desktop ]]; then
        log_pass "✓ GNOME Session 配置正確"
        return 0
    else
        log_warn "⚠️  GNOME Session 配置檔案不存在"
        return 1
    fi
}

# ==============================================================================
# Safety Checks
# ==============================================================================

safety_check_gui() {
    log_info "Step 8: 執行 GUI 安全檢查..."
    
    local checks_passed=0
    
    # 檢查 1: GNOME Shell
    if rpm -q gnome-shell &>/dev/null; then
        log_pass "✓ GNOME Shell 已安裝"
        ((checks_passed++))
    else
        log_err "❌ GNOME Shell 未安裝"
    fi
    
    # 檢查 2: GNOME Terminal
    if rpm -q gnome-terminal &>/dev/null; then
        log_pass "✓ GNOME Terminal 已安裝"
        ((checks_passed++))
    else
        log_err "❌ GNOME Terminal 未安裝"
    fi
    
    # 檢查 3: X11 或 Wayland
    if rpm -q xorg-x11-server-Xvfb &>/dev/null || rpm -q wayland &>/dev/null; then
        log_pass "✓ 顯示伺服器已配置"
        ((checks_passed++))
    else
        log_warn "⚠️  顯示伺服器可能未完全配置"
    fi
    
    if [[ $checks_passed -ge 2 ]]; then
        log_pass "✓ GUI 安全檢查通過 ($checks_passed/3)"
        return 0
    else
        log_err "❌ GUI 安全檢查失敗"
        return 1
    fi
}

# ==============================================================================
# Main Installation Flow
# ==============================================================================

main() {
    clear
    
    echo -e "${C_INFO}╔════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_INFO}║  Albert SIT Environment Deployment     ║${C_RESET}"
    echo -e "${C_INFO}║         v3.5 (GUI Safe)                ║${C_RESET}"
    echo -e "${C_INFO}╚════════════════════════════════════════╝${C_RESET}"
    echo ""
    
    log_info "開始 SIT 環境部署..."
    echo ""
    
    # Pre-flight checks
    check_root
    check_rhel_version || log_warn "⚠️  系統版本警告，繼續執行"
    check_location
    echo ""
    
    # Installation steps
    log_info "=== 開始安裝依賴 ==="
    echo ""
    
    install_core_tools || log_err "❌ 核心工具安裝失敗"
    install_gnome_desktop || log_warn "⚠️  GNOME Desktop 安裝失敗，嘗試繼續"
    install_gnome_terminal || log_err "❌ GNOME Terminal 安裝失敗"
    configure_ldconfig
    
    echo ""
    log_info "=== 配置 GNOME 環境 ==="
    echo ""
    
    bypass_gnome_initial_setup
    bypass_accessibility_prompt
    verify_gnome_session
    
    echo ""
    log_info "=== 執行安全檢查 ==="
    echo ""
    
    safety_check_gui
    
    echo ""
    echo -e "${C_PASS}╔════════════════════════════════════════╗${C_RESET}"
    log_pass "安裝完成！系統已準備就緒"
    echo -e "${C_PASS}╚════════════════════════════════════════╝${C_RESET}"
    echo ""
    echo -e "${C_INFO}後續步驟：${C_RESET}"
    echo "  1. 重新啟動系統: ${C_WARN}sudo reboot${C_RESET}"
    echo "  2. 以 root 身份登入"
    echo "  3. 執行配置: ${C_WARN}sudo bash ver.sh${C_RESET}"
    echo "  4. 開始測試: ${C_WARN}sudo bash regression_test.sh${C_RESET}"
    echo ""
}

# ==============================================================================
# Entry Point
# ==============================================================================

main "$@"