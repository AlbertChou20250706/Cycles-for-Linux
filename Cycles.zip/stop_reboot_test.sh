#!/bin/bash

################################################################################
# Albert SIT - 緊急止損腳本 (Emergency Stop)
# Version  : 1.1 (繁中版本 + 多重清理)
# 用途     : 立即中止 REBOOT/AC/DC/SHUTDOWN 測試,防止下次重啟自動繼續
# 用法     : sudo bash stop_reboot_test.sh
################################################################################

set -euo pipefail

# Colors
readonly C_INFO="\e[1;36m"
readonly C_PASS="\e[1;32m"
readonly C_WARN="\e[1;33m"
readonly C_ERROR="\e[1;31m"
readonly C_RESET="\e[0m"

log_info()  { echo -e "${C_INFO}[INFO]${C_RESET} $1"; }
log_pass()  { echo -e "${C_PASS}[PASS]${C_RESET} $1"; }
log_warn()  { echo -e "${C_WARN}[WARN]${C_RESET} $1"; }
log_error() { echo -e "${C_ERROR}[ERROR]${C_RESET} $1"; }

echo ""
echo -e "${C_WARN}════════════════════════════════════════════════════════════════${C_RESET}"
echo -e "${C_WARN}🛑 緊急止損腳本 - 立即中止所有自動測試${C_RESET}"
echo -e "${C_WARN}════════════════════════════════════════════════════════════════${C_RESET}"
echo ""

# ────────── 權限檢查 ──────────
if [[ $EUID -ne 0 ]]; then
    log_error "此腳本需要 root 權限"
    echo "  請使用: sudo bash stop_reboot_test.sh"
    exit 1
fi

# ────────── 檢查當前狀態 ──────────
log_info "檢查當前測試狀態..."
echo ""

readonly STATE_FILE="/root/Documents/Albert_Cycle_State.ini"
readonly SESSION_FILE="/root/Documents/.current_session"
readonly AUTOSTART_FILE="${HOME}/.config/autostart/auto_test.desktop"
readonly QUEUE_FILE="config/test_queue.run"

if [[ -f "$STATE_FILE" ]]; then
    echo -e "${C_INFO}=== 當前測試狀態 ===${C_RESET}"
    cat "$STATE_FILE" | sed 's/^/    /'
    echo ""

    CURRENT_TYPE=$(grep "^TEST_TYPE=" "$STATE_FILE" 2>/dev/null | cut -d= -f2 || echo "UNKNOWN")
    CURRENT_CYCLE=$(grep "^CURRENT_CYCLE=" "$STATE_FILE" 2>/dev/null | cut -d= -f2 || echo "?")
    MAX_CYCLES=$(grep "^MAX_CYCLES=" "$STATE_FILE" 2>/dev/null | cut -d= -f2 || echo "?")

    log_warn "正在執行: $CURRENT_TYPE (第 ${CURRENT_CYCLE} / ${MAX_CYCLES} 圈)"
else
    log_info "STATE_FILE 不存在,測試可能已結束或尚未開始"
fi

echo ""
echo -e "${C_WARN}採取的行動:${C_RESET}"
echo ""

# ────────── 1. 取消 RTC 鬧鐘 ──────────
if command -v rtcwake &>/dev/null; then
    log_info "取消 RTC 鬧鐘 (防止自動喚醒)..."
    if rtcwake -m disable 2>/dev/null; then
        log_pass "✓ RTC 鬧鐘已取消"
    else
        log_warn "  RTC 鬧鐘取消失敗 (可能本來就沒設)"
    fi
else
    log_warn "rtcwake 命令不存在,略過"
fi

# ────────── 2. 移除 autostart ──────────
if [[ -f "$AUTOSTART_FILE" ]]; then
    log_info "移除 autostart..."
    rm -f "$AUTOSTART_FILE"
    log_pass "✓ Autostart 已移除 (下次重啟不會自動執行測試)"
else
    log_info "Autostart 不存在,無需移除"
fi

# 同時清理可能的舊版位置
rm -f /etc/auto_test.desktop 2>/dev/null || true
# 也清理當前工作目錄下的 .desktop 檔案
rm -f ./auto_test.desktop 2>/dev/null || true

# ────────── 3. 移除狀態檔案 ──────────
if [[ -f "$STATE_FILE" ]]; then
    log_info "移除狀態檔案..."
    rm -f "$STATE_FILE"
    log_pass "✓ Albert_Cycle_State.ini 已刪除"
fi

# ────────── 4. 移除會話檔案 ──────────
if [[ -f "$SESSION_FILE" ]]; then
    log_info "移除會話檔案..."
    rm -f "$SESSION_FILE"
    log_pass "✓ .current_session 已刪除"
fi

# ────────── 5. 清理測試佇列 ──────────
if [[ -f "$QUEUE_FILE" ]]; then
    log_info "清理測試佇列..."
    rm -f "$QUEUE_FILE"
    log_pass "✓ 測試佇列已清空"
fi

# ────────── 6. 移除工作目錄記錄 ──────────
if [[ -f "/usr/auto.pwd" ]]; then
    log_info "移除工作目錄記錄..."
    rm -f /usr/auto.pwd
    log_pass "✓ /usr/auto.pwd 已刪除"
fi

# ────────── 完成 ──────────
echo ""
echo -e "${C_PASS}════════════════════════════════════════════════════════════════${C_RESET}"
log_pass "✅ 測試已完全中止"
echo -e "${C_PASS}════════════════════════════════════════════════════════════════${C_RESET}"
echo ""

echo -e "${C_INFO}當前狀態確認:${C_RESET}"
echo "  • Autostart   : $([[ ! -f "$AUTOSTART_FILE" ]] && echo "✓ 已移除" || echo "✗ 仍存在")"
echo "  • RTC 鬧鐘    : ✓ 已取消"
echo "  • 狀態檔案    : $([[ ! -f "$STATE_FILE" ]] && echo "✓ 已刪除" || echo "✗ 仍存在")"
echo "  • 測試佇列    : $([[ ! -f "$QUEUE_FILE" ]] && echo "✓ 已清空" || echo "✗ 仍存在")"
echo ""

echo -e "${C_INFO}下一步:${C_RESET}"
echo ""
echo "  ① 重新配置測試 (僅 DC 2 圈):"
echo "       sudo bash ver.sh"
echo "       (REBOOT/AC/SHUTDOWN 都選 N,DC 選 y 並設 2 圈)"
echo ""
echo "  ② 啟動測試:"
echo "       sudo bash regression_test.sh"
echo ""

echo -e "${C_WARN}⚠️  重要提醒:${C_RESET}"
echo "  • 本腳本已阻止系統重啟後自動執行測試"
echo "  • 若機器目前已掉電/重啟,可安全開機"
echo "  • 注意: 所有未保存的工作已遺失"
echo ""
